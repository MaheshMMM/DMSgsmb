<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\DashboardModel;
use App\Models\VehicleReservationModel;
use App\Models\DocumentsModel;
class Dashboard extends Controller {
    public $dashModel;
    public $vehresModel;
    public $session;
    public $epf_no;
    public $docModel;
    public function __construct(){
        helper('form');
    $this -> session = \config\Services::session();
    $this-> dashModel = new DashboardModel(); 
    $this-> vehresModel = new VehicleReservationModel(); 
    $this-> docModel = new DocumentsModel();
    }
    public function index(){
        if(!session()->has('logged_user')){
            return redirect()->to(base_url()."/login");
       }
       $epf_no=session()->get('logged_user');
       $data['userdata']= $this->dashModel->getLoggedInUserData($epf_no);
       $data['chartdata']=$this->docModel->doc_cat_dash();
       return view("dashboard_view",$data);
    }
    public function logout(){
        if(session()->has('logged_info')){
                $la_id=session()->get('logged_info');
                $this->dashModel->updateLogoutTime($la_id);
        }
         //echo print_r($la_id);
        session() ->remove('logged_user');
        session() -> destroy();
        return redirect()->to(base_url()."/login");
    }
    public function vehicleReservation(){
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'epf_no' => 'required',
                'route'=> 'required',
                'distination'=> 'required',
                'rq_date'=>'required',
                'rt_date'=>'required',
                'part'=>'required',
                'reason'=>'required'
                ];
            if($this->validate($rules))
            {
                $vhdata=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'route' =>$this->request->getVar('route'),
                    'distination' =>$this->request->getVar('distination'),
                    'rq_date' =>$this->request->getVar('rq_date'),
                    'rt_date' =>$this->request->getVar('rt_date'),
                    'part' =>$this->request->getVar('part'),
                    'remark' =>$this->request->getVar('remark'),
                    'reason' =>$this->request->getVar('reason'),
                    ];
                if($this->vehresModel->vehreseradd($vhdata)){
                 $this->session->setTempdata('success', "Resevation submited",6);
                return redirect()->to(current_url()); 
               }
                
            }
            else
            {
                $data['validation'] = $this->validator;   
            }
        }
       if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
         $data['userdata']= $this->dashModel->findLogindata($la_id);
        }
          //print_r($data);
          return view("VehicleReservation_view",$data);
      
    }
    public function VehicleReservationUpdate(){
        
       if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        // $data['userdata']= $this->dashModel->findLogindata($la_id);
        }
        $data["resdata"]=$this->dashModel->findAll();
        return view("UserRervationDisplay_view",$data);
        
       // print_r($data);
    }
    public function VehicleResUpdateDone($id){
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'epf_no' => 'required',
                'route'=> 'required',
                'distination'=> 'required',
                'rq_date'=>'required',
                'rt_date'=>'required',
                'part'=>'required',
                'reason'=>'required'
                ];
            if($this->validate($rules))
            {
                $vhdata=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'route' =>$this->request->getVar('route'),
                    'distination' =>$this->request->getVar('distination'),
                    'rq_date' =>$this->request->getVar('rq_date'),
                    'rt_date' =>$this->request->getVar('rt_date'),
                    'part' =>$this->request->getVar('part'),
                    'remark' =>$this->request->getVar('remark'),
                    'reason' =>$this->request->getVar('reason'),
                    ];
                if($this->dashModel->VehResupdate($id,$vhdata)){
                 $this->session->setTempdata('success', "Reservation Updated",6);
                return redirect()->to(current_url()); 
               }
                
            }
            else
            {
                $data['validation'] = $this->validator;   
            }
        }
        $data['veh']=$this->dashModel->find($id);
        return view("venicleResevationUpadate_view",$data);
    }
    }

