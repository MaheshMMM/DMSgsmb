<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\DocumentsModel;
use App\Models\VehicleIssueModel;

class Report_new extends Controller
{
    public $docModel;
    public $vehIssModel;
    public $repdata = [];
    public function __construct(){
        helper('form');
      $this-> docModel=new DocumentsModel();  
      $this-> vehIssModel=new VehicleIssueModel(); 
    }
    public function index() 
	{
         $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            
                $data=[
                    'st_date' =>$this->request->getVar('st_date'),
                    'en_date'=> $this-> request->getVar('en_date'),
                    'doc_type' =>$this->request->getVar('Types'),
                     ];
                $repdata['docs'] = $this->docModel->Doc_Report_PW($data);
                //print_r($repdata);
                return view('reports_view',$repdata);                   
        }
         
        
        // $data['alldrivers']=$this->vehissuemodel->list_of_drivers();
        return view("ReportQuery_view");
         //print_r($data);
      }
         public function Doc_mineral() 
	{
         $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            
                $data=[
                    
                     ];
                $repdata['docs'] = $this->docModel->Doc_Report_Min($data);
                //print_r($repdata);
                return view('MineraSummery_View',$repdata);                   
        }
         
        
        // $data['alldrivers']=$this->vehissuemodel->list_of_drivers();
        return view("ReportMinQuery_view");
         //print_r($data);
      }
    public function Doc_Move_find() 
	{
         $data = [];
         if ($this->request->getMethod() == 'post')
        {
            
                $sdata=[
                    'App_no' =>$this->request->getVar('App_no'),
                    
                     ];
                $movdata['docs'] = $this->docModel->Doc_Mov_RelatedAll_Display($sdata);
                //print_r($movdata);
               return view('Movements_All_Display_View',$movdata);                   
        }
         
        
         $data['docAll']=$this->docModel->findAll();
        return view("Doc_LocationQuery_view",$data);
        // print_r($data);
      }

    
 public function Veh_Issue_find() 
	{
         $data = [];
         if ($this->request->getMethod() == 'post')
        {
            
                $sdata=[
                    'App_no' =>$this->request->getVar('App_no'),
                    
                     ];
                $movdata['docs'] = $this->docModel->vehicleIssueTo();
                //print_r($movdata);
               return view('');                   
        }
         
        
         $data['docAll']=$this->docModel->Summery_Report_Min();
        return view("Veh_Issue_query_view");
        // print_r($data);
      }
    public function MineralSummery() 
	
                                  
    {
        
        $data['docAll']=$this->docModel->findAll();
        return view("MineraSummery_View",$data);
        // print_r($movdata);
      }
    
}
function htmlToPDF(){
       $repdata['docs'] = $this->docModel->findAll();    
       $dompdf = new \Dompdf\Dompdf(); 
       $dompdf->loadHtml(view('Reports_view',$repdata));
       $dompdf->setPaper('A4', 'landscape');
       $dompdf->render();
       $dompdf->stream();
        
    }