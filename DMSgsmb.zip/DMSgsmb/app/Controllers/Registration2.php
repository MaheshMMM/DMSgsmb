<?php
namespace App\Controllers;
use \CodeIgniter\Controller;
use App\Models\RegistrationModel;

class Registration extends Controller {
     public $regisModel;
     public $session;
     public $parser;
    public function __construct(){
       helper('Form');
       helper('date');
       $this -> regisModel= new RegistrationModel();
       $this -> session = Session();
       $parser = \Config\Services::parser();
    }
    public function index(){
        
        $data = [];
        $data['validation']=null;
        $session = \CodeIgniter\Config\Services::session();
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'epf_no' => 'required|min_length[2]|max_length[4]|is_unique[users.epf_no]|numeric',
                'name' => 'required|min_length[4]|max_length[100]',
                'email'=> 'required|valid_email|is_unique[users.email]',
                'pass'=> 'required|min_length[6]|max_length[16]',
                'cpass'=>'required|matches[pass]',
                'desi'=>'required',
                'addre'=>'required',
                'mobile'=>'required|numeric|exact_length[10]'
                ];
            if($this->validate($rules))
            {
                $uniid = md5(str_shuffle('abcdefghijklmnopqrstuvwxyz'.time()));
                $empdata=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'name'=> $this-> request->getVar('name',FILTER_SANITIZE_STRING),
                    'desi' =>$this->request->getVar('desi'),
                    'addre' =>$this->request->getVar('addre'),
                    'mobile' =>$this->request->getVar('mobile'),
                    'phone' =>$this->request->getVar('phone'),
                    'email' =>$this->request->getVar('email'),
                    'dept' =>$this->request->getVar('dept'),
                    'unit' =>$this->request->getVar('unit'),
                    's_unit' =>$this->request->getVar('s_unit'),
                    'pw' =>password_hash($this->request->getVar('pass'),PASSWORD_DEFAULT),
                    'email' =>$this->request->getVar('email'),
                    'uniid' => $uniid
                   ];
                if($this->regisModel->createemploy($empdata)){
                    //$result = "Account created successfully";
                    //echo "<script language='javascript'>alert(\"$result\");location=\"index\"</script>";
                $session->setTempdata('Success', "Account create successfully",3);
                return redirect()->to(current_url()); 
               }
                else{
                    $session->setTempdata('Error', "Can't create account, try again latter",3);
                    return redirect()->to(current_url()); 
                }
            }
            else
            {
                $data['validation'] = $this->validator;   
            }
        }
        $data['desig'] =$this->regisModel->designation();
           return view("Registration_view",$data);
      }
    public function activate($uniid=null){
      $data=[];
      if(!empty($uniid)){
          $userdata = $this->regisModel->verifyUniid($uniid);
          if($userdata){
             if($this->verifyExpireTime($userdata->activation_date)){
             echo 'Okey';
             }
          else{
              $data['error']='sorry activate link was expired';
            }
            }
          else{
              $data['error']='sorry unable to process your Account';
          }
      }
      else
      {
          $data['error']='Sorry! unable to process your request';
      }
      return view("activate_view",$data);
      }
public function verifyExpireTime($regTime){
    $currTime = now();
    $regTime=strtotime($regTime);
    $difTime = (int)$currTime - (int)$regTime;
    if(3600 < $difTime){
        return true;
    }
    else{
        return false;
    }
   
}
 public function viewDesi(){
     $data['desig'] =$this->regisModel->designation();
   echo print_r($data);
    //return view('registration_view',$data);
 }
 
}
