<?php

namespace App\Controllers;
use \CodeIgniter\Controller;
use \App\Models\VehicleIssueModel;
use \App\Models\DashboardModel;
class VehicleIssue extends Controller{
    public $vehissuemodel;
    public $session;
    public $parser;
    public $dashmodel;
    public function __construct(){
      helper('form');
      $this ->vehissuemodel = new VehicleIssueModel();
      $this -> session = \config\Services::session();
      $this -> parser = \config\Services::parser();
      $this -> dashmodel = new DashboardModel();
      helper('sendsms');
    }
   public function index(){
       
   }
   public function driversAdd(){
       $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'dri_class' => 'required',
                'lice_valid_from'=> 'required',
                'lice_valid_to'=> 'required',
                'attach_unit'=>'required',
                'attach_veh'=>'required'
                ];
            if($this->validate($rules))
            {
                $data=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'dri_class'=> $this-> request->getVar('dri_class'),
                    'lice_valid_from' =>$this->request->getVar('lice_valid_from'),
                    'lice_valid_to' =>$this->request->getVar('lice_valid_to'),
                    'features' =>$this->request->getVar('features'),
                    'attach_unit' =>$this->request->getVar('attach_unit'),
                    'attach_veh' =>$this->request->getVar('attach_veh'),
                    ];
                if($this->vehissuemodel->adddriver($data)){
                     $this->session->setTempdata('success','Vehicle Reserved Completed',3);
                      return redirect()->to(current_url());
                }
                       
                   else{
                        $this->session->setTempdata('error', "Unable to save",3);
                      return redirect()->to(current_url()); 
                  // $data=$this->email->printDebugger(['headers']);
                  // print_r($data);
                  }
        }
         $data['validation'] = $this->validator;        
        }
        
         $data['alldrivers']=$this->vehissuemodel->list_of_drivers();
        return view("driver_view",$data);
        // echo print_r($data);
      }
      
      public function vehicleIssuependingdisplay(){
        $data['veh_iss_pen']= $this->vehissuemodel->veh_issue_pending();
       //$data['veh_reservation']=$this->approModel->findAll();
       return view("veh_iss_pending_view",$data);
        }
      public function vehicleissue($id=null){
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'reserve_id' => 'required',
                ];
            if($this->validate($rules))
            {
                $data=[
                    'reserve_id' =>$this->request->getVar('reserve_id'),
                    'driver_id'=> $this-> request->getVar('driver_id'),
                    'vehicle_id' =>$this->request->getVar('vehicle_id'),
                    'i_office' =>$this->request->getVar('vehicle_id'),
                    'remark' =>$this->request->getVar('remark'),
                    ];
                if($this->vehissuemodel->vehicleissuesave($data)){
                     $this->session->setTempdata('success','Driver save Completed',3);
                      return redirect()->to(current_url());
                }
                else{
                        $this->session->setTempdata('error', "Unable to save",3);
                      return redirect()->to(current_url()); 
                  // $data=$this->email->printDebugger(['headers']);
                  // print_r($data);
                  }
        }
         $data['validation'] = $this->validator;        
        }
        
         //$data['alldrivers']=$this->vehissuemodel->vehicleissuesave();
        //return view("driver_view",$data);
        // echo print_r($data);
            if(session()->has('logged_info')){
            $la_id=session()->get('logged_info');
            $data['userdata']= $this->dashmodel->findLogindata($la_id);
            }
            $data['veh']=$this->vehissuemodel->find($id);
            $data['driverlist']=$this->vehissuemodel->join();
            $data['vehiclelist']=$this->vehissuemodel->availableVehicleList();
            return view("vehicleissue_view",$data);
            }
        //first approval view
    public function pendingdisplay(){
        if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $userdata= $this->dashmodel->findLogindata($la_id);
            if($userdata['s_unit']=='3'){
             $data['veh_reservation']= $this->vehissuemodel->verify_no_approval();
            //$data['veh_reservation']=$this->approModel->findAll();
            return view("firstapproval_view",$data);
            }
            else{
             $this->session->setTempdata('error', "You have no permission",3);
             return redirect()->to(base_url().'/dashboard');
            }
        }
       else{
       $this->session->setTempdata('error', "Currently ",3);
       return redirect()->to(base_url().'/dashboard');
       }
    }
    public function finalpendingdisplay(){
        if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $userdata= $this->dashmodel->findLogindata($la_id);
            if($userdata['s_unit']=='1'){
             $data['veh_reservation']= $this->vehissuemodel->verify_hod_approval();
       //$data['veh_reservation']=$this->approModel->findAll();
       return view("finalapproval_view",$data);
            }
            else{
             $this->session->setTempdata('error', "You have no permission",3);
             return redirect()->to(base_url().'/dashboard');
            }
        }
       else{
       $this->session->setTempdata('error', "Currently ",3);
       return redirect()->to(base_url().'/dashboard');
       }
        
    }
    public function firstapproved($id=null){
      if($this->vehissuemodel->update_vr_approval($id,'id')){  
          $this->session->setTempdata('success','Successfully approved',3);
          return redirect()->to(base_url()."/VehicleIssue/pendingdisplay");
      }
    }
    public function finalapproved($id=null){
      if($status=$this->vehissuemodel->update_hod_approval($id,'id')){ 
         if($status== true){
             $data['success'] = 'Approved successfuly';
              return redirect()->to(base_url(). "/VehicleIssue/finalpendingdisplay"); 
         } 
        }
     }
      public function FindAvailableDriver(){
          
           //if($this->request->getMethod()=='post')
         $data['av_dri'] = $this->vehissuemodel->join();
      //echo view("vehicleissue_view",$data);
          
         echo '<pre>';
         print_r($data);
         echo '<pre>';
      }
      
      
    function sendsms($mobileno, $message){

    sendsms( '94779181676', 'Hello world, this is a test message' );
    }
}
   

