<?php
namespace App\Controllers;
use \CodeIgniter\Controller;
use App\Models\VehicleRegistrationModel;

class Vehicles extends Controller {
     public $vehicleregisModel;
     public $session;
         
    public function __construct(){
       helper('form');
       
       $this -> vehicleregisModel= new VehicleRegistrationModel();
       $this -> session = \config\Services::session();
      
    }
    public function index(){
        
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'v_no' => 'required|is_unique|min_length[7]|max_length[9]',
                'v_type' => 'required',
                'p_seats'=> 'required|numeric',
                'p_year'=> 'exact_length[4]|numeric',
                'v_own'=>'required',
                ];
            if($this->validate($rules))
            {
                $vehdata=[
                    'v_no' =>$this->request->getVar('v_no'),
                    'v_type'=> $this-> request->getVar('v_type'),
                    'p_seats' =>$this->request->getVar('p_seats'),
                    'p_year' =>$this->request->getVar('p_year'),
                    'v_own' =>$this->request->getVar('v_own'),
                    ];
                if($this->vehicleregisModel->addvehicle($vehdata)){
                     $this->session->setTempdata('Error','Vehicle Save Completed',3);
                      return redirect()->to(current_url());
                }
                       
                   else{
                      $this->session->setTempdata('Error', "Unable to save",3);
                      return redirect()->to(current_url()); 
                  // $data=$this->email->printDebugger(['headers']);
                  // print_r($data);
                  }
     }
         $data['validation'] = $this->validator;        
        }
        return view("Vehicles_view",$data);
      }
    }
