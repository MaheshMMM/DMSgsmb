<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\LoginModel;

class Login extends Controller {
    public $loginModel;
    public $session;
    public $parser;
    public function __construct(){
        helper('form');
        $this->loginModel = new LoginModel();
        $this->session = session();
        $parser = \Config\Services::parser();
    }
    public function index(){
        $data = [];
        $validation[]=null;
        if($this->request->getMethod() == 'post'){
            $rules = [
               'epf_no' => 'required|min_length[2]|max_length[4]|numeric',
                'pw'=> 'required|min_length[6]|max_length[16]', 
            ];
           if($this->validate($rules)){
              $epf_no = $this->request->getVar('epf_no');
              $password = $this->request->getVar('pw');
              $userdata = $this ->loginModel->verifyEPF($epf_no);
              
              if($userdata){
                 if (password_verify($password,$userdata['pw'])){
                    if($userdata['status']=='active'){
                        if($userdata['p_level']=='1'){
                          $logininfo=[
                            'epf_no' => $userdata['epf_no'],
                            'agent'=> $this->getUserAgentInfo(),
                            'ip'=> $this->request->getIPAddress(),
                            'log_in'=> date('Y-m-d h:i:s')
                            ];
                            $la_id=$this->loginModel->saveLoginInfo($logininfo);
                            if($la_id){
                            $this->session->set('logged_info',$la_id);
                            }
                            $this->session->set('logged_user',$userdata['epf_no']);
                            return redirect()->to(base_url().'/dashboard');
                            }
                         elseif ($userdata['p_level']=='4'){
                          $logininfo=[
                            'epf_no' => $userdata['epf_no'],
                            'agent'=> $this->getUserAgentInfo(),
                            'ip'=> $this->request->getIPAddress(),
                            'log_in'=> date('Y-m-d h:i:s')
                            ];
                            $la_id=$this->loginModel->saveLoginInfo($logininfo);
                            if($la_id){
                            $this->session->set('logged_info',$la_id);
                            }
                            $this->session->set('logged_user',$userdata['epf_no']);
                            return redirect()->to(base_url().'/dashboard');
                            }
                            else{
                          $logininfo=[
                            'epf_no' => $userdata['epf_no'],
                            'agent'=> $this->getUserAgentInfo(),
                            'ip'=> $this->request->getIPAddress(),
                            'log_in'=> date('Y-m-d h:i:s')
                            ];
                            $la_id=$this->loginModel->saveLoginInfo($logininfo);
                            if($la_id){
                            $this->session->set('logged_info',$la_id);
                            }
                            $this->session->set('logged_user',$userdata['epf_no']);
                            return redirect()->to(base_url().'/dashboard');  
                            }
                            }
                            
                    else{
                      $this->session->setTempdata('Error','Please activate your Account',3);
                     return redirect()->to(current_url());  
                    }
                 } 
                 else{
                     $this->session->setTempdata('Error','Wrong password entered for the User',3);
                     return redirect()->to(current_url());
                   }
              }
              else{
                  $this ->session->setTempdata('Error','Sorry! Epf_no does not exists',3);
                  return redirect()-> to(current_url());
            }
           }
           else{
               $data['validation'] = $this->validator;
           }
        }
        return view("login_view",$data);
    }
      
   
    public function getUserAgentInfo(){
        $agent = $this->request->getUserAgent();
        if($agent->isBrowser()){
            $currentAgent=$agent->getBrowser();
        }elseif($agent->isRobot()){
            $currentAgent = $this->agent->robot();
        }elseif($agent->isMobile()){
           $currentAgent=$agent->getMobile(); 
        }else{
            $currentAgent='Unidentified User Agent';
        }
       return $currentAgent; 
    }
   
}
