<?php
namespace App\Controllers;
use \CodeIgniter\Controller;
use App\Models\VehicleReservationModel;

class VehicleReservation extends Controller {
     public $vehreserveModel;
     public $session;
     public $parser;
    public function __construct(){
       helper('form');
       helper('date');
       $this -> vehreserveModel= new VehicleReservationModel();
       $this -> session = Session();
       $parser = \Config\Services::parser();
    }
    public function index(){
        
        $data = [];
        $data['validation']=null;
       
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'epf_no' => 'required',
                'route'=> 'required',
                'distination'=> 'required',
                'rq_date'=>'required',
                'rt_date'=>'required',
                'part'=>'required',
                'reason'=>'required'
                ];
            if($this->validate($rules))
            {
                $vhdata=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'route' =>$this->request->getVar('route'),
                    'distination' =>$this->request->getVar('distination'),
                    'rq_date' =>$this->request->getVar('rq_date'),
                    'rt_date' =>$this->request->getVar('rt_date'),
                    'part' =>$this->request->getVar('part'),
                    'remark' =>$this->request->getVar('remark'),
                    'reason' =>$this->request->getVar('reason'),
                    ];
                if($this->vehreserveModel->vehreseradd($vhdata)){
                $session->setTempdata('Success', "Reservation successfully",6);
                return redirect()->to(current_url()); 
                }else{
                $session->setTempdata('Error', "Can't Reserve, try again latter",6);
                return redirect()->to(current_url());   
                }
              }
            else
            {
                $data['validation'] = $this->validator;   
            }
        }
        
           return view("VehicleReservation_view",$data);
      }
        
     
 
}
