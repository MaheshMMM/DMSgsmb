<?php

namespace App\Controllers;

use \CodeIgniter\Controller;

class Users extends Controller
{
    public function __construct()
    {
        helper('form');
    }
    public function index()
    {
        $data = [];
        $data['validation']=null;
        $rules=[
            'name'=> 'required', 
            'mobile'=> 'required',
            'email'=> 'required',
        ];
        if($this ->request->getMethod() == 'post')
            {
          if($this-> validate($rules))
              { 
              echo "Success";
        }
         else
         {
       $data['validation'] = $this -> validator;  
         }
         
        }
        return view('myview',$data);
    }
            
        
    }
