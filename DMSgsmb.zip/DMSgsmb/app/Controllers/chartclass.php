
<html>
  <head>
      <?php
        $con = mysqli_connect("localhost","root","","dmsgsmb");
        $sql = "select catagory, Count(*)as number from Documents group by catagory ";
        $query = mysqli_query($con,$sql);
     ?>
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
   google.charts.load('current', {'packages':['corechart']});
   google.charts.setOnLoadCallback(drawChart);
   function drawChart() {
   var data = new google.visualization.arrayToDataTable([
          ['Category','Number'],
          <?php
          while($row=mysqli_fetch_array($query))
          {
              echo"['".$row["catagory"]."',".$row["number"]."],";
          }
          ?>
      ]);
     var options = {'title':'How Much Pizza I Ate Last Night',
                     'width':400,
                     'height':300};
      var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>
  </head>

  <body>
//Div that will hold the pie chart
    <div id="chart_div" style="width:400; height:300"></div>
  </body>
</html>