<?php

namespace App\Controllers;
use App\Models\ApprovalModel;

class Home extends BaseController
{
    public $appModel;
    public function __construct(){
        $this->parser= \Config\Services::patser();
       $this-> appModel = new ApprovalModel();
        helper('form');
        
    }
    public function index(){
        echo view("homeview") ;
    }
   
}
