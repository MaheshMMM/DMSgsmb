<?php


namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\DocumentsModel;

class VehReports extends \CodeIgniter\Controller {
    public function __construct(){
      $this-> docModel=new DocumentsModel();  
    }
    public function index() 
	{
       // $data['docs'] = $this->docModel->findAll();
        return view('ReportVeh_view');
        
    } //put your code here
}
