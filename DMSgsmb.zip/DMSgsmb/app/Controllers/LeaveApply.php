<?php

namespace App\Controllers;
use \CodeIgniter\Controller;
use App\Models\LeaveApplyModel;
use \App\Models\DashboardModel;
class LeaveApply extends Controller {
     public $session;
     public $leaveappmodel;
       public function __construct(){
         helper('Form');
         helper('date');
       $this -> session = \config\Services::session();
       $this->leaveappmodel= new LeaveApplyModel();
       $this -> dashmodel = new DashboardModel;
       }
       public function index(){
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'epf_no' => 'required',
                'leave_type' => 'required',
                'leave_nos'=> 'required',
                'start_date'=> 'required',
                'end_date'=>'required',
                'reason'=> 'required',
                 ];
            if($this->validate($rules))
            {
                 $data=[
                    'epf_no' =>$this->request->getVar('epf_no'),
                    'leave_type' =>$this->request->getVar('leave_type'),
                    'leave_nos' =>$this->request->getVar('leave_nos'),
                    'start_date' =>$this->request->getVar('start_date'),
                    'end_date' =>$this->request->getVar('end_date'),
                    'reason' =>$this->request->getVar('reason'),
                    'remark' =>$this->request->getVar('remark'),
                     ];
                 if($this->leaveappmodel->ApplyLeave($data)){
                   $this->session->setTempdata('success', "Request Send successfully",3);
                      return redirect()->to(current_url());
                }
                  else{
                    $this->session->setTempdata('errors', "Unable to save",3);
                      return redirect()->to(current_url()); 
                  // $data=$this->email->printDebugger(['headers']);
                  // print_r($data);
                  }
            }
          $data['validation'] = $this->validator; 
       }
       if(session()->has('logged_info')){
            $la_id=session()->get('logged_info');
            $data['userdata']= $this->dashmodel->findLogindata($la_id);
            }
       return view("leaveapply_view",$data);   
        }
}
