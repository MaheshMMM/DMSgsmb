<?php

namespace App\Libraries;
use App\Models\AutoModel;
use CodeIgniter\HTTP\URI;

class TestLibrary {
    public $db;
    public $am;
    public $email;
    public $uri;
    public function __construct(){
        $this->db = \config\database::connect();
        $this->email = \config\services::email();
        $this->am = new \App\Models\AutoModel();
        $this->uri = new URI(current_url());
        helper('form');
    }
    public function getData(){
        return $this->uri->hetHost();
    }
    public function displayData(){
        return $this->am->findAll();
        
    }
}
