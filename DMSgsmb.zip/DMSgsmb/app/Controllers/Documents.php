<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\DocumentsModel;
use \App\Models\DashboardModel;
class Documents extends Controller {
     public $docModel;
     public $session;
     public $parser;
     public $dashmodel;
      
public function __construct(){
       helper('form');
       helper('date');
       $this -> docModel= new DocumentsModel();
       $this -> session = Session();
       $parser = \Config\Services::parser();
       $this -> dashmodel = new DashboardModel;
       
    }
    public function index(){
      $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'app_name' => 'required|min_length[4]|max_length[50]|is_unique[documents.app_no]',
                'catagory' => 'required|min_length[4]|max_length[10]',
                'mineral' => 'required|min_length[4]|max_length[20]',
                ];
            if($this->validate($rules))
            {
                $data=[
                    'doc_type' =>$this->request->getVar('doc_type'),
                    'app_no' =>$this->request->getVar('app_no'),
                    'lice_no'=> $this-> request->getVar('lice_no',FILTER_SANITIZE_STRING),
                    'catagory' =>$this->request->getVar('catagory'),
                    'mineral' =>$this->request->getVar('mineral'),
                    'app_name' =>$this->request->getVar('app_name'),
                    'reg_office' =>$this->request->getVar('reg_office'),
                    'received_by' =>$this->request->getVar('epf_no'),
                    'status' =>'Pending',
                    'current_location' =>$this->request->getVar('epf_no'),
                    ];
                if($this->docModel->docsave($data)){
                $this->session->setTempdata('success', "Application submited",6);
                return redirect()->to(current_url()); 
                  
                }
                else{
                    $this->session->setTempdata('Error', "Can't submited, try again latter",3);
                      return redirect()->to(current_url()); 
                }
            }
            else
            {
             $data['validation'] = $this->validator;   
            }
          }
       if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $data['userdata']= $this->dashmodel->findLogindata($la_id);
       return view("Documents_view",$data);
        }
      }
 
    public function pendingApprovaldisplay(){
        $data['doc_appr']= $this->docModel->doc_for_approval();
       
       return view("Doc_approval_display",$data);
    }
   public function Approved_Update($id=null){
      $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'app_no' => 'required|min_length[2]|max_length[50]',
                   ];
            if($this->validate($rules))
            {
                     $data=[
                    'status' =>$this->request->getVar('status'),    
                    'auth_officer' =>$this->request->getVar('epf_no'),
                    'remark' =>$this->request->getVar('remark'),
                    'current_location'=>$this->request->getVar('re_by'),
                    ];
                     $mdata=[
                    'app_no' =>$this->request->getVar('app_no'),
                    'movement_no' =>'1',
                    'officer' =>$this->request->getVar('epf_no'),
                    'send_to'=>$this->request->getVar('re_by'),
                    ];
                   $this->docModel->doc_Move_save($mdata);    
                if($this->docModel->update_doc_approval($id,$data)){
                $this->session->setTempdata('Success', "Application submited",3);
                return redirect()->to(base_url()."/Documents/pendingApprovaldisplay"); 
                }
                else{
                    $this->session->setTempdata('Error', "Can't submited, try again latter",3);
                     return redirect()->to(base_url()."/Documents/pendingApprovaldisplay"); 
                }
            }
            else
            {
               $data['validation'] = $this->validator;   
            }
          }
       if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $data['userdata']= $this->dashmodel->findLogindata($la_id);
                     }
        $data['appdata']= $this->docModel->ApplicationAllData($id);
                  
       return view("Registrar_view",$data);
      // print_r($data);
      }
public function move_Pending(){
      if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $data['userdata']= $this->dashmodel->findLogindata($la_id);
        }
       
       $udata['cur_loc']=$this->docModel->Doc_Mov_Pen_Display(session()->get('logged_user'));
       //print_r($udata);
       return view("Doc_pending_display",$udata);
   }

    public function Doc_Movement_save($id){
        $data = [];
        $data['validation']=null;
        if ($this->request->getMethod() == 'post')
        {
            $rules = [
                'app_no' => 'required|min_length[2]|max_length[50]',
                   
                 ];
            if($this->validate($rules))
            {
                     $data=[
                    'app_no' =>$this->request->getVar('app_no'),
                    'movement_no'=> 1+$this->request->getVar('movement_no'),
                    'officer' =>$this->request->getVar('epf_no'),    
                    'send_to' =>$this->request->getVar('send_to'),
                    'remark' =>$this->request->getVar('remark'),
                    ];
                     $udata=[
                      'current_location'=> $this->request->getVar('send_to')
                     ];
                 $this->docModel->document_movement_change($id,$udata);    
                if($this->docModel->doc_Move_save($data)){
                    $this->session->setTempdata('Success', "Application submited",3);
                    return redirect()->to(base_url()."/Documents/move_Pending"); 
                }
                else{
                    $this->session->setTempdata('Error', "Can't submited, try again latter",3);
                      return redirect()->to(current_url()); 
                }
            }
            else
            {
                
             $data['validation'] = $this->validator;   
            }
            
        }
       if(session()->has('logged_info')){
        $la_id=session()->get('logged_info');
        $data['userdata']= $this->dashmodel->findLogindata($la_id);
                     }
        $data['appdata']= $this->docModel->ApplicationDetailLoad($id);
        $data['user']= $this->docModel->userlist(); 
        
       return view("Doc_move_view",$data);
      // print_r($data);
      }
     
     
}
