 <?= $this ->extend("Layout/Base_top_mgt"); ?> 

    
<?= $this ->section("content");?>
<div class="row justify-content-center align-items-center p-3">
    <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
        <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Vehicle Issued Details </h2>  
             <?= form_open(); ?>
             <div>
             <div class="form-group ">
                <label class="required">Start Date</label>
                <input type="date" name="st_date" class="form-control" value=''>
              
            </div>
            
            <div class="form-group ">
                <label class="required">End Date</label>
                <input type="date" name="en_date"  class="form-control" value=''>
              
            </div>
                 
                 </div> 
                 
           
              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
               
            </div>
             </div>
          <?= form_close(); ?>
        </div>
                
    </div>
</div>
                
<?= $this->endsection(); ?>
