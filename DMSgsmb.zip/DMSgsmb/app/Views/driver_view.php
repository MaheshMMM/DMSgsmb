<?php $page_session = \Config\Services::session(); ?>
<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
             <?php if($page_session->getTempdata('success')): ?>
             <p class='alert alert-success'><?= $page_session->getTempdata('success'); ?> </p>
            <?php endif; ?>
             <?php if($page_session->getTempdata('error')): ?>
             <p class='alert alert-danger'><?= $page_session->getTempdata('error'); ?> </p>
             <?php endif; ?>
            <div class="form-box">
        
             <h2>Drivers Registration Form</h2>  
          
        <?= form_open(); ?>
        
            <div class="form-group">
                <label class="required">EPF No / Name</label>
                <select  name="epf_no" class="form-control">
                
                <option value="">No Selected</option>
                 <?php if(!empty($alldrivers)>0): ?>
                    <?php foreach($alldrivers as $row):?>
                <option value=<?= $row->epf_no?>  </option><?= $row->epf_no;?>
                
                    <?php endforeach;?>
                 <?php endif; ?>
            </select>
            </div>
            <div class="form-group ">
                <label class="required">Driving License Allow Vehicle Type</label>
                <input type="text" name="dri_class" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'dri_class') ?></span>
            </div>
            <div class="form-group">
                <label class="required">Driving License Valid Start</label>
                <input type="text" name="lice_valid_from" class="form-control" >
             <span class="text-danger"><?= display_error($validation,'lice_valid_from') ?></span>   
            </div>
            <div class="form-group ">
                <label class="required">Driving License Valid End</label>
                <input type="text" name="lice_valid_to" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'lice_valid_to') ?></span>
            </div>
            <div class="form-group ">
                <label class="required">Extra Features</label>
                <input type="text" name="features" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'features') ?></span>
            </div>
            <div class="form-group ">
                <label class="required">Attached Unit</label>
                <input type="text" name="attach_unit" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'attach_unit') ?></span>
            </div>
             <div class="form-group ">
                <label class="required">Attached Vehicle</label>
                <input type="text" name="attach_veh" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'attach_veh') ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                
            </div>
            
            <?= form_close(); ?>
            </div>
            </div>
                
        </div>
       
    
<?= $this ->endsection();?>