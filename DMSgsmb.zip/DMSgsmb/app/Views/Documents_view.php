<?= $this ->extend("Layout/Base_top_mgt"); ?> 
 <?php $page_session = \Config\Services::Session(); ?>
        <?= $this ->section("page_loger"); ?>
         <span> Welcome <?= ucfirst($userdata['name']); ?></span>
        <?= $this ->endsection(); ?>
<?= $this ->section("content");?>
                       
             
     <div class="row justify-content-center align-items-center p-3">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Document Receive Form</h2> 
             
              <?php if(session()->getTempdata('success')): ?>
             <div class='alert alert-success'> 
             <?= session()->getTempdata('success'); ?>
             </div>
             <?php endif; ?>
             <?= form_open(); ?>
            <div class="form-group ">
                <label >Employ ID</label>
                <input type="text" name="epf_no" class="form-control" value='<?= $userdata['epf_no']; ?>'>
            </div>
            <div class="form-group">
                <label class="required">Document type</label>
                 <select name="doc_type" class="form-control" >
                    <option>  </option>
                    <option> Mining License</option>
                    <option> Trading License</option>
                    <option> Export License</option>
                    <option> Exploration License</option>
                 </select>
            </div>
            <div class="form-group ">
                <label class="required">Application no</label>
                <input type="text" name="app_no" class="form-control" value=''>
               <span class="text-danger"><?= display_error($validation,'app_no'); ?> </span>
            </div>
             <div class="form-group ">
                <label >License no</label>
                <input type="text" name="lice_no" class="form-control" value=''>
             </div>
            <div class="form-group ">
                <label class="required">Category</label>    
              <select name="catagory" class="form-control" >
                    <option>  </option>
                    <option> IML/A</option>
                    <option> IML/B</option>
                    <option>IML/C</option>
                    <option> IML/D</option>
                    <option> AL/A</option>
                    <option> AL/B</option>
                    <option>TDL/A</option>
                    <option> TDL/B</option>
                 </select>
                
            </div>
            <div class="form-group ">
                <label class="required">Mineral</label>
               <select name="mineral" class="form-control" >
                    <option> </option>
                    <option> River Sand</option>
                    <option> Inland Sand</option>
                    <option> Sea Sand</option>
                    <option> Aggregate</option>
                    <option> Gravel</option>
                    <option> Soil</option>
                    <option> Brick Clay</option>
                    <option> Tile Clay</option>
                    <option> Ball Clay</option>
                    <option> Graphite</option>
                    <option> Granite</option>
                    <option> Feldspar</option>
                    <option> Phosphate</option>
                    <option> Gold</option>
                    <option> Rutile</option>
                    <option> Mineral Sand</option>
                    <option> Silica Sand</option>
              </select>
              </div>
            <div class="form-group ">
                <label>Name of the applicant</label>
                <input type="text" name="app_name" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'app_name'); ?> </span>
            </div>
            <div class="form-group ">
                <label>Regional Office</label>
               <select name="reg_office" class="form-control" >
                    <option> </option>
                    <option> Anuradhapura R/O</option>
                    <option> Ampara R/O</option>
                    <option> Badulla R/O</option>
                    <option> Batticalloa R/O</option>
                    <option> Gampaha R/O</option>
                    <option> Colombo R/O</option>
                    <option> Jaffna R/O</option>
                    <option> Kandy R/O</option>
                    <option> Kurunegala R/O</option>
                    <option> Kalutara R/O</option>
                    <option> Kanthale S/O</option>
                    <option> Kegalle R/O</option>
                    <option> Matara R/O</option>
                    <option> Matale R/O</option>
                    <option> Polonnaruwa R/O</option>
                    <option> Hambanthota R/o</option>
                    <option> Hasalaka S/O</option>
                    <option> Rathnapura R/O</option>
                    <option> Trincomalee R/o</option>
                    <option> Monaragala R/O</option>
                    <option> Mannar S/O</option>
                    <option> Vavuniya R/O</option>
              </select>
                
            </div>
            <div class="form-group">
                 <label>Related Document-PDF</label>
                <input type="file" name="app_image" class="form-control" id="inputGroupFile02">
                
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <!--<input type="reset" class="btn btn-default" on-click="rsFunction()" value="Reset"> -->
            
            </div>
            </div>
        </div>    
        </div>
   
<?= $this->endsection(); ?>
