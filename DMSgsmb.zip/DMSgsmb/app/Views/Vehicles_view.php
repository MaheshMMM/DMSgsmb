<?php $page_session = \Config\Services::session(); ?>
<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box border rounded bg-white p-3 text-info">
        
             <h2>Vehicle Registration Form</h2>  
           <?php if($page_session->getTempdata('success')): ?>
             <div class='alert alert-success'><?= $page_session->getTempdata('success'); ?> </div>
            <?php endif; ?>
             <?php if($page_session->getTempdata('error')): ?>
             <div class='alert alert-danger'><?= $page_session->getTempdata('error'); ?> </div>
             <?php endif; ?>
        <?= form_open(); ?>
        
            <div class="form-group">
                <label class="required">Vehicle Registration No</label>
                <input type="text" name="v_no" class="form-control" >
                 <span class="text-danger"><?= display_error($validation,'v_no') ?></span>
            </div>
            <div class="form-group ">
                <label class="required">Vehicle Type</label>
               <select name="v_type" class="form-control" >
                    <option> -Select Vehicle Type-</option>
                    <option> Car</option>
                    <option> Van</option>
                    <option> Double Cab</option>
                    <option> Lorry</option>
                    <option> Bus</option>
                    <option> Jeef</option>
                    <option> 3W</option>
                                      
              </select>
            </div>
            <div class="form-group">
                <label class="required">Passenger Seats</label>
                <input type="text" name="p_seats" class="form-control" >
             <span class="text-danger"><?= display_error($validation,'p_seats') ?></span>   
            </div>
            <div class="form-group ">
                <label class="required">Product year</label>
                <input type="text" name="p_year" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'p_year') ?></span>
            </div>
            <div class="form-group ">
                <label class="required">Vehicle Owner</label>
                <input type="text" name="v_own" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'v_own') ?></span>
            </div>
            
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
               
            </div>
            
            <?= form_close(); ?>
            </div>
            </div>
                
        </div>
       
    
<?= $this ->endsection();?>