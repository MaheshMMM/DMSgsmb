 <?= $this ->extend("Layout/Base_top_mgt"); ?> 

    
<?= $this ->section("content");?>
<div class="row justify-content-center align-items-center p-3">
    <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
        <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Find Location </h2>  
             <?= form_open(); ?>
             <div>
             <div class="form-group"> 
                 <label class="required">Application No:</label>
                <select class="form-control" name="App_no" >
                 <?php if(!empty($docAll)>0): ?>
                 <?php foreach($docAll as $row):?>
                <option value=<?= $row['App_no'];?>  </option><?= $row['App_no'];?>
                 <?php endforeach;?>
                 <?php endif; ?>
            </select>
                 
                 </div> 
                 
           
              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
               
            </div>
             </div>
          <?= form_close(); ?>
        </div>
                
    </div>
</div>
                
<?= $this->endsection(); ?>
