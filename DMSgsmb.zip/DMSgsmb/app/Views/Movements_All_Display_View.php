<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>

<section>
    <h2 class="title">Documents Received List</h2>
    <div class="row">
            <div class="container"> 
            <?php if(!empty($docs)>0): ?>
            <table class='table table-dark table-striped'>
            <tr>
                <th> Movement Order</th>
                <th> Applicant Name</th>
                <th> Application No</th>
                <th> Received Date & Time</th>
                <th> Send To</th>
                <th> Send Date & Time</th>
            </tr>
            <?php foreach($docs as $res): ?>
            <tr>
                <td> <?= $res->movement_no; ?></td>
                <td> <?= $res->app_name; ?></td>
                <td> <?= $res->App_no; ?></td>
                <td> <?= $res->received_date; ?></td>
                <td> <?= $res->name; ?></td>
                <td> <?= $res->datetime; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
            </div>
        </div>  
      
    
</section>

<?= $this ->endsection();?>
