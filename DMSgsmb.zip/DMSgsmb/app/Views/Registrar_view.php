<?= $this ->extend("Layout/Base_top_mgt"); ?> 
   <?php $page_session = \Config\Services::Session(); ?>
<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center p-2">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Documents Approval Process(Registrar)</h2>  
                        
             <?= form_open(); ?>
             <div class="form-group ">
                <label class="required">User ID</label>
                <input type="text" name="epf_no" value='<?= $userdata->epf_no ?>' class="form-control" />
                
            </div>
            <div class="form-group">
                  <?php if(!empty($appdata)>0): ?>
                    <?php foreach($appdata as $row):?>
                <label class="required">Application No</label>
                <input type="text" name="app_no" class="form-control" value=<?= $row->App_no ?> >
               
                  <?php endforeach;?>
                 <?php endif; ?>
            </div>
             <div class="form-group">
                  <?php if(!empty($appdata)>0): ?>
                    <?php foreach($appdata as $row):?>
                <label class="required">Application Receiver</label>
                
                <input type="text" name="re_by" class="form-control" value=<?= $row->received_by ?> >
                  <?php endforeach;?>
                 <?php endif; ?>
            </div>
             <div class="form-group ">
                <label class="required">Recommendetion</label>
               <select name="status" class="form-control" >
                    <option>  </option>
                    <option> Approved</option>
                    <option> Pending</option>
                    
                </select>
              </div>
            <div class="form-group">
                <label class="required">Remark</label>
                <input type="text" name="remark" class="form-control" />
             
            </div>
           
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit"/>
             </div>
             
             <?= form_close(); ?>   
             </div>
        </div>
     </div>
<?= $this ->endsection();?>