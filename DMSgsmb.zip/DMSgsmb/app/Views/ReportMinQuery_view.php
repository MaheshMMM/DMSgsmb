 <?= $this ->extend("Layout/Base_top_mgt"); ?> 

    
<?= $this ->section("content");?>
<div class="row justify-content-center align-items-center p-3">
    <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
        <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Document Report </h2>  
             <?= form_open(); ?>
             <div>
             <div class="form-group"> 
                 <label class="required">Mineral</label>
                 <select name="mineral" class="form-control" >
                    <option> </option>
                    <option> River Sand</option>
                    <option> Inland Sand</option>
                    <option> Sea Sand</option>
                    <option> Aggregate</option>
                    <option> Gravel</option>
                    <option> Soil</option>
                    <option> Brick Clay</option>
                    <option> Tile Clay</option>
                    <option> Ball Clay</option>
                    <option> Graphite</option>
                    <option> Granite</option>
                    <option> Feldspar</option>
                    <option> Phosphate</option>
                    <option> Gold</option>
                    <option> Rutile</option>
                    <option> Mineral Sand</option>
                    <option> Silica Sand</option>
              </select>
                 </div>  
            <div class="form-group ">
                <label class="required">Start Date</label>
                <input type="date" name="st_date" class="form-control" value=''>
              
            </div>
            
            <div class="form-group ">
                <label class="required">End Date</label>
                <input type="date" name="en_date"  class="form-control" value=''>
              
            </div>
              <div class="form-group">
                <input type="" class="btn btn-primary" value="Submit">
               
            </div>
                 </div>
              <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Stack">
               
            </div>
             </div>
          <?= form_close(); ?>
        </div>
                
    </div>
</div>
                
<?= $this->endsection(); ?>
