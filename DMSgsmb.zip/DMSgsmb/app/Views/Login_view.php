
<?= $this ->extend("Layout/base_home"); ?> 
<?php $page_session = \Config\Services::Session(); ?>

<?= $this ->section("content");?>
     <div class="row " >
        <div class = "col-sm-2">
        </div>
    <div class="col-sm-8">
      <div class="container-sm border border-danger rounded p-3 my-4 bg-white text-white">
        <div class="row">
          <div class="border-right col-md-6 ">
            
             <div class="left" >
             <img  src="<?= base_url(); ?>/public/assets/images/loginicon.jpg" alt="logo img">   
             </div>
          </div>
            <div class="col-md-6">
                <?= form_open(); ?>
             <div class="right"> 
               <?php if(isset($validation)):?>
                <div class="alert alert-danger">
                 <?= $validation->listErrors(); ?>
                </div>
               <?php endif; ?>  
                    <div class="formbox text-info p-4">
                        <h3 class="title text-primary">User Login </h3>  
                        <p>Please fill in your credentials to login<p>
                        <div class="form-group ">
                        <label>User Id:</label>
                        <input type="text" name="epf_no" class="form-control" placeholder="Online">
                        <span class="help-block"></span>
                        </div>   
                        <div class="form-group ">
                        <label>Password:</label>
                        <input type="password" name="pw" class="form-control"  placeholder="*******">
                        <span class="help-block"></span>
                        </div>
                        <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Login">
                        <p>Don't have an account? <a href="<?= base_url(); ?>/Registration">Sign up now</a>.</p>
                        </div>
                    </div>
             </div>
                  <?= form_close(); ?>     
            </div>
        </div>
      </div>
     </div>
        <div class="col-sm-2">
            
        </div>
</div>
               
      
    
<?= $this ->endsection(); ?>