<div class="container width-auto"> 
    <h2 class='text-center text-primary'>Current Process</h2>
    <div class="row ">
       
     
  <div class=" border rounded shadow-lg p-2 m-2 ">
   <div id="chart_div"  style="width:100%;max-width:500px; "  ></div>
  </div>
  <div class=" border rounded shadow-lg p-2 m-2">
   <div id="chart_div1" style="width:100%;max-width:500px"></div>
  </div>
  <div class=" border rounded shadow-lg p-2 m-2">
    <canvas id="pieChart" style="width:100%;max-width:500px"></canvas>
  </div> 
        </div>
        <h2 class='text-center text-primary'>Annual Progress</h2>
        <div class="row ">
       
    <div class='col-md-12 width-50px higth-50px text-center p-1'>
    <div class=" border rounded shadow-lg p-2 m-2">
     <canvas id="mlChart" style="width:Auto;max-width:900px"></canvas>
    </div>
    </div>
        
        
    </div>
    </div>
    

    
