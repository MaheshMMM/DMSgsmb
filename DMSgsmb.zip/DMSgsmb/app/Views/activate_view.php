<?= $this->extend("layout/Base_top_mgt"); ?>

<?= $this-> section("content"); ?>
<div class="contain">
    <h1> activation process   </h1>
    <?php if(isset($error)): ?>
    <div class="alert alert-danger">
        <?= $error; ?>
    </div>
    <?php endif; ?>
</div>
<?= $this-> endsection(); ?>
