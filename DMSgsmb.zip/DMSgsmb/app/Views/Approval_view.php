<?= $this ->extend("layout/Base_top_mgt"); ?>
<?php $this-> section("content"); ?>
<section>
    <div class="container">
        
    <h2 class='title'> Pending Approval List</h2>
    <div class="row">
        <?php if(!empty($veh_reservation)>0): ?>
        <table class='table table-dark table-striped'>
            <tr>
                <th> Employer_No</th>
                <th> Destination</th>
                <th> Via</th>
                <th> Reserved Date</th>
                <th> Departure Time</th>
                <th> Return Date</th>
                <th> Return Time</th>
                <th> No of Participations</th>
                <th> Remarks</th>
                <th> Recommendation</th>
            </tr>
            <?php foreach($veh_reservation as $res): ?>
            <tr>
                <td> <?= $res->epf_no; ?></td>
                <td> <?= $res->distination; ?></td>
                <td> <?= $res->route; ?></td>
                <td> <?= $res->rq_date; ?></td>
                <td> <?= $res->rq_time; ?></td>
                <td> <?= $res->rt_date; ?></td>
                <td> <?= $res->rt_time; ?></td>
                <td> <?= $res->part; ?></td>
                <td> <?= $res->remark; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/dashboard/approved/<?= $res->id ?>">Approval</a>
                    
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
     </div>
</section>
<?= $this->endsection(); ?>