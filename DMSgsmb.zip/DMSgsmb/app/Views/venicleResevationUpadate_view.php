<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center p-3">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
            
        
             <h2>Vehicle Reservation  Update Form</h2>  
             
           <?php if(!empty($errors)): ?>
             <div class="alert alert-denger">
             <?php foreach($errors as $field => $error): ?>
                 <p> <?= $error ?></p>
             <?php endforeach ?>
             </div>
           <?php endif; ?>
              
             <?php if(session()->getTempdata('success')): ?>
             <div class='alert alert-success'> 
             <?= session()->getTempdata('success'); ?>
             </div>
             <?php endif; ?>
             
             <?= form_open(); ?>
          <div class="form-group">
                <label class="required">Resevation ID</label>
                <input type="text" name="epf_no" value="<?= $veh['id']; ?>" class="form-control" />
                 
            </div>
        
            <div class="form-group">
                <label class="required">User ID(EPF No)</label>
                <input type="text" name="epf_no" value="<?= $veh['epf_no']; ?>" class="form-control" />
                 
            </div>
            <div class="form-group ">
                <label class="required">Reason for reservation</label>
                <input type="text" name="reason" value="<?= $veh['reason']; ?>" class="form-control" />
                
            </div>
            <div class="form-group">
                <label class="required">Route(Via)</label>
                <input type="text" name="route" value="<?= $veh['route'] ?>" class="form-control" />
                
            </div>
            <div class="form-group ">
                <label class="required">Destination</label>
                <input type="text" name="distination" value="<?= $veh['distination'] ?>" class="form-control" />
            </div>
            <div class="form-group ">
                <label class="required">Request Date/Time</label>
                <input type="datetime-local" name="rq_date" id="datepicker" value="<?= $veh['rq_date'] ?>" class="form-control" />
            </div>
            
            <div class="form-group ">
                <label class="required">return date/Time</label>
                <input type="datetime-local" name="rt_date" id="datetimepicker" value="<?= $veh['rt_date'] ?>" class="form-control" />
                
            </div>
            <div class="form-group ">
                <label class="required">No of Partitions</label>
                <input type="text" name="part" value="<?= $veh['part'] ?>" class="form-control" />
            </div>
            <div class="form-group ">
                <label class="required">Remarks</label>
                <input type="text" name="remark" value="<?= $veh['remark'] ?>" class="form-control" />
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Update"/>
             </div>
             
             
             <?= form_close(); ?>  
            </div>
        </div>
     </div>
<?= $this ->endsection();?>
