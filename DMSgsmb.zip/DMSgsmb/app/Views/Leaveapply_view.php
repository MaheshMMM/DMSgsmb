<?= $this ->extend("Layout/Base_top_mgt"); ?> 
<?php $page_session = \Config\Services::Session(); ?>
<?= $this ->section("page_loger"); ?>
         <span> Welcome <?= ucfirst($userdata['name']); ?></span>
        <?= $this ->endsection(); ?>
<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center p-3">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Leave Apply Form</h2>  
             
           
              
             <?php if(session()->getTempdata('success')): ?>
             <div class='alert alert-success'> 
             <?= session()->getTempdata('success'); ?>
             </div>
             <?php endif; ?>
             
             <?= form_open(); ?>
                 
            <div class="form-group">
                <label class="required">User ID(EPF No)</label>
                <input type="text" name="epf_no" class="form-control" />
                <span class="text-danger"><?= display_error($validation,'epf_no'); ?> </span> 
            </div>
              <div class="form-group">
                <label class="required">Leave Type</label>
                <select name="leave_type" class="form-control" >
                    <option> -select leave type-</option>
                    <option> Casual</option>
                    <option> Annual</option>
                    <option> Medical</option>
                    <option> Lieu leave</option>
                    <option> Duty</option>
              </select>
            </div>
            <div class="form-group ">
                <label class="required">Reason for Leave</label>
                <input type="text" name="reason" class="form-control" />
                <span class="text-danger"><?= display_error($validation,'reason'); ?> </span> 
            </div>
            <div class="form-group ">
                <label class="required">Leave Start Date Date</label>
                <input type="date" name="start_date"  class="form-control" />
                <span class="text-danger"><?= display_error($validation,'start_date'); ?> </span> 
            </div>
            <div class="form-group ">
               <label class="required">Leave End Date Date</label>
               <input type="date" name="end_date" class="form-control" />
               <span class="text-danger"><?= display_error($validation,'end_date'); ?> </span> 
              </div>
            <div class="form-group ">
                <label class="required">No of day Leave</label>
                <input type="text" name="leave_nos" class="form-control" />
                <span class="text-danger"><?= display_error($validation,'leave_nos'); ?> </span> 
            </div>
            <div class="form-group ">
                <label class="required">Remarks</label>
                <input type="text" name="remark" class="form-control" />
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit"/>
             </div>
             <?= form_close(); ?>   
             </div>
        </div>
     </div>
<?= $this ->endsection();?>
