<?= $this ->extend("Layout/base_home"); ?> 
 <?php $page_session = CodeIgniter\Config\Services::session(); ?>
<?= $this ->section("content");?>
     <div class="row justify-content-center p-2  align-items-center">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box border rounded bg-white p-3 text-info">
        
             <h2 class="text-center text-primary">Registration Form</h2>  
             <?php if ($page_session->getTempdata('success')): ?>
             <div class='alert alert-success'> <?= $page_session->getTempdata('success'); ?></div>
             <?php endif; ?>
        
             <?php if ($page_session->getTempdata('error')): ?>
             <div class='alert alert-denger'> <?= $page_session->getTempdata('error'); ?></div>
             <?php endif; ?>
         
             <?= form_open(); ?>
             
            <div class="form-group">
                <label class="required">User ID(EPF No)</label>
                <input type="text" name="epf_no" class="form-control"  value=''>
                <span class="text-danger"><?= display_error($validation,'epf_no'); ?> </span>  
            </div>
            <div class="form-group ">
                <label class="required">Employ name</label>
                <input type="text" name="name" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'name'); ?> </span>
            </div>
            <div class="form-group">
                <label class="required">Designation:</label>
                <select class="form-control" name="desi" >
                 <?php if(!empty($desig)>0): ?>
                 <?php foreach($desig as $row):?>
                <option value=<?= $row->desi;?>  </option><?= $row->desi;?>
                 <?php endforeach;?>
                 <?php endif; ?>
            </select>
            </div>
            <div class="form-group ">
                <label class="required">Employ Address</label>
                <input type="text" name="addre" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'addre'); ?> </span> 
            </div>
            <div class="form-group ">
                <label class="required">Mobile No</label>
                <input type="text" name="mobile" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'mobile'); ?> </span>  
            </div>
            <div class="form-group ">
                <label>Home Phone No</label>
                <input type="text" name="phone" class="form-control" value=''>
            </div>
            <div class="form-group ">
                <label class="required">Email Address</label>
                <input type="text" name="email" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'email'); ?> </span>  
            </div>
            <div class="form-group ">
                <label class="required">Department</label>
                <select name="dept" class="form-control" >
                    <option>  </option>
                    <option> Mining</option>
                    <option> Geology</option>
                    <option> Finance</option>
                    <option> HR</option>
                    <option> Legal</option>
                    <option> Audit</option>
                </select>
            <span class="text-danger"><?= display_error($validation,'dept'); ?> </span>     
            </div>
            <div class="form-group ">
                <label class="required">Working Unit</label>
                <select name="unit" class="form-control" >
                    <option> </option>
                    <option> Chr unit</option>
                    <option> DG unit</option>
                    <option> SD unit</option>
                    <option> Dir unit</option>
                    <option> CME unit</option>
                    <option> SRMT unit</option>
                    <option> Mineral Titling</option>
                    <option> Mapping</option>
                    <option> Laboratory</option>
                    <option> Mines Safety</option>
                    <option> Mineral Survey</option>
                    <option> Seismology</option>
                    <option> Administrative</option>
                    <option> Human Resource</option>
                    <option> Procurement</option>
                    <option> Enforcement</option>
                    <option> Regional Office</option>
              </select>
                <span class="text-danger"><?= display_error($validation,'unit'); ?> </span> 
            </div>
            <div class="form-group ">
                <label>Working Sub Unit</label>
                <select name="s_unit" class="form-control" >
                    <option> </option>
                    <option> Cartography</option>
                    <option> Transport</option>
                    <option> Petrology Lab</option>
                    <option> Complains</option>
                    <option> Anuradhapura</option>
                    <option> Ampara</option>
                    <option> Badulla</option>
                    <option> Batticalloa</option>
                    <option> Gampaha</option>
              </select>
                 
            </div>
            <div class="form-group ">
                <label class="required">Password(atleast 6 charactors)</label>
                <input type="password" name="pass" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'pass'); ?> </span>   
            </div>
            <div class="form-group" >
                <label class="required">Confirm Password</label>
                <input type="password" name="cpass" class="form-control" >
                <span class="text-danger"><?= display_error($validation,'cpass'); ?> </span>   
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <!--<input type="reset" class="btn btn-default" on-click="rsFunction()" value="Reset"> -->
            </div>
            <p>Already have an account? <a href="login">Login here</a>.</p>
            <?= form_close(); ?>
            </div>
            </div>
                
        </div>
   
<?= $this->endsection(); ?>
