<?= $this ->extend("Layout/Base_top_mgt"); ?> 
    <?= $this ->section("page_loger"); ?>
     <span> Welcome <?= ucfirst($userdata->name); ?></span>
    <?= $this ->endsection(); ?>
<?= $this ->section("content");?>
<div class="row bg-light">
<section>
    <div class="col-md-12  align-left ">
        <?= $this->include("widgets/left_sidebar") ?>
    </div>  
</section>
       
<section id="features">
    <div class="col-md-12 pt-2 align-center">
     <?= $this->include("partials/features") ?>
    </div>  
</section>

</div>  
<?= $this ->endsection();?>
