<?= $this ->extend("Layout/Base_top_mgt"); ?> 
<?php $page_session = \Config\Services::session(); ?>
        <?= $this ->section("page_loger"); ?>
        <span> Welcome <?= ucfirst($userdata['name']); ?></span>
        <?= $this ->endsection(); ?>
    <?= $this ->section("content");?>
     <div class="row justify-content-center align-items-center p-3">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
             <?php if($page_session->getTempdata('success')): ?>
             <p class='alert alert-success'><?= $page_session->getTempdata('success'); ?> </p>
            <?php endif; ?>
             <?php if($page_session->getTempdata('error')): ?>
             <p class='alert alert-danger'><?= $page_session->getTempdata('error'); ?> </p>
             <?php endif; ?>
            <div class="form-box border rounded bg-white p-3 text-info">
            <h2>Vehicle Issues Form</h2>  
        <?= form_open(); ?>
            <div class="form-group">
                <label class="required">reservation No</label>
                <input type="text" name="reserve_id" class="form-control" value="<?= $veh['id']; ?>">
            </div>
             <div class="form-group">
                <label class="required">Request Officer</label>
                <input type="text" name="name" class="form-control" value="<?= $veh['name']; ?>">
            </div>
             <div class="form-group">
                <label class="required">Destination</label>
                <input type="text" name="desi" class="form-control" value="<?= $veh['desi']; ?>">
            </div>
             <div class="form-group">
                <label class="required">Department</label>
                <input type="text" name="dept" class="form-control" value="<?= $veh['dept']; ?>">
            </div>
            <div class="form-group ">
                <label class="required">Driver ID</label>
                <select name="driver_id" id="save2" onchange="save2" class="form-control">
                <option value="">No Selected</option>
                 <?php if(!empty($driverlist)>0): ?>
                 <?php foreach($driverlist as $row):?>
                <option value=<?= $row->id ?>  </option><?= $row->epf_no. '/' .$row->name;?>
                 <?php endforeach;?>
                 <?php endif; ?>
                </select>
            </div> 
            <div class="form-group">
                <label class="required">Issued Vehicle No</label>
                <select name="vehicle_id" id="save2" onchange="save2" class="form-control">
                <option value="">No Selected</option>
                 <?php if(!empty($vehiclelist)>0): ?>
                 <?php foreach($vehiclelist as $row):?>
                <option value=<?= $row->v_no ?>  </option><?= $row->v_no;?>
                 <?php endforeach;?>
                 <?php endif; ?>
                </select>
            </div>
            <div class="form-group ">
                <label class="required">Remarks</label>
                <input type="text" name="remark" class="form-control" >
               </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="submit">
            </div>
         <?= form_close(); ?>
            </div>
        </div>
    </div>
<?= $this ->endsection();?>
