<?= $this ->extend("layout/Base_top_mgt"); ?>
<?php $this-> section("content"); ?>
<section>
    <div class="container">
        
    <h2 class='title'> Pending Vehicle Issue List</h2>
        
         
    <div class="row">
        <?php if(!empty($veh_iss_pen)>0): ?>
        <table class='table table-dark table-striped'>
            <tr>
                <th> Reservation Id</th>
                <th> Employee Name</th>
                <th> Designation</th>
                <th> Destination</th>
                <th> Via</th>
                <th> Reserved Date/Time</th>
                <th> Return Date/Time</th>
                <th> No of Participations</th>
                <th> Remarks</th>
                <th> Recommendation</th>
                
            </tr>
            <?php foreach($veh_iss_pen as $res): ?>
            <tr>
                 <td> <?= $res->id; ?></td>
                <td> <?= $res->name; ?></td>
                <td> <?= $res->desi; ?></td>
                <td> <?= $res->distination; ?></td>
                <td> <?= $res->route; ?></td>
                <td> <?= $res->rq_date; ?></td>
                <td> <?= $res->rt_date; ?></td>
                <td> <?= $res->part; ?></td>
                <td> <?= $res->remark; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/VehicleIssue/vehicleissue/<?= $res->id ?>">Issuing</a>
                    
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
     </div>
</section>
<?= $this->endsection(); ?>