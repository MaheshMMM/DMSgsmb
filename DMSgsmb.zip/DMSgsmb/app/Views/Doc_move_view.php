<?= $this ->extend("Layout/Base_top_mgt"); ?> 
   <?php $page_session = \Config\Services::Session(); ?>
<?= $this ->section("content");?>
   
     <div class="row justify-content-center align-items-center p-2">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Documents Movements Management</h2>  
                        
             <?= form_open(); ?>
             <div class="form-group ">
                <label class="required">User ID</label>
                <input type="text" name="epf_no" value='<?= $userdata['epf_no'] ?>' class="form-control" />
                
            </div>
            <div class="form-group">
                  <?php if(!empty($appdata)>0): ?>
                    <?php foreach($appdata as $row):?>
                <label class="required">Application No</label>
                <input type="text" name="app_no" class="form-control" value=<?= $row->App_no; ?>>
                  <?php endforeach;?>
                 <?php endif; ?>
            </div>
            <div class="form-group ">
                <label class="required">Send To</label>
                <select class="form-control" name="send_to" >
                 <?php if(!empty($user)>0): ?>
                    <?php foreach($user as $row):?>
                <option value=<?= $row->epf_no;?>  </option><?= $row->desi;?> &nbsp; / &nbsp<?= $row->name;?>
                
                    <?php endforeach;?>
                 <?php endif; ?>
            </select>
            </div>
            <div class="form-group">
                  <?php if(!empty($appdata)>0): ?>
                    <?php foreach($appdata as $row):?>
                
                <input type="text" name="movement_no" class="form-control" value=<?= $row->max ?>>
                  <?php endforeach;?>
                 <?php endif; ?>
            </div>
            <div class="form-group">
                <label class="required">Remark</label>
                <input type="text" name="remark" class="form-control" />
             
            </div>
           
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit"/>
             </div>
             
             <?= form_close(); ?>   
             </div>
        </div>
     </div>
<?= $this ->endsection();?>
