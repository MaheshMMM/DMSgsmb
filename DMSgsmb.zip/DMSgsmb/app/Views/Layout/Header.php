<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
    
</head>
<body>
    <header>
<div id="banner">
    <ul>
      <li>  <img src="http://localhost/DMSgsmb/public/assets/images/banner.png"></li>
    </ul>
</div> 
<nav class="navbar navbar-expand-lg navbar-dark mynav">
<div class="container">
      <div id ="home">
        <ul>
          <li class="pad"><a href="#"><span>Home</span></a></li>
        </ul>
      </div>
      <div id ="services">
        <ul>
          <li class="pad"><a href="#"><span>Services</span></a> </li>
        </ul>
      </div>
      <div id ="contacts">
        <ul>
          <li class="pad"><a href="contract.html"><span>Contacts</span></a></li>
        </ul>
      </div>
      <div id ="network">
        <ul>
          <li class="pad"><a href="network.html"><span>Our Network</span></a></li>
        </ul>
      </div>
      <div id ="about">
        <ul>
          <li class="pad"><a href="#"><span>About</span></a> </li>
        </ul>
      </div>
  </div>
</nav>
</header>