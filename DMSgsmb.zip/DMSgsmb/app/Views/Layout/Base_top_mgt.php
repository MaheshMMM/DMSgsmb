<!DOCTYPE html>

<html lang="en">
<head>
    <title>Sign Up</title>
   <meta charset="utf-8">
   <?php
        $con = mysqli_connect("localhost","root","","dmsgsmb");
        $sql = "select catagory, Count(*)as number from Documents group by catagory ";
        $query = mysqli_query($con,$sql);
        $sql1 = "select mineral, Count(*)as number from Documents group by mineral ";
        $query1 = mysqli_query($con,$sql1);
     ?>
   
   <!-- CSS only -->
       <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
       <link rel="stylesheet" href="<?= base_url(); ?>/public/assets/CSS/styleregister.css"> 
       <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>/public/assets/js/jquery-ui.min.css">

</head>
<body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-3.6.0.slim.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <header>
        <div class="row">
            <div class="col-md-4">
               <div id="banner">
                <ul>
                <li>  <img src="http://localhost/DMSgsmb/public/assets/images/banner.png"></li>
                
                </ul>
            </div> 
            </div>
            <div class="col-md4 mt-5 font-weight-bold ">
                <nav class="navbar navbar-expand-sm bg-secondry navbar-dark ">
                   
                  
                    <a class="nav-link dropdown-toggle" href="<?= base_url(); ?>/dashboard" ><span>Dashboard</span></a>
                  
                
                
            <div id ="services">
                <ul class="navbar-nav justify-content-center w-100 px-3">
                   <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Vehicle
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="<?= base_url(); ?>/dashboard/vehicleReservation"><span>Reservation</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/dashboard/VehicleReservationUpdate"><span>Reservation Update</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/vehicleIssue/vehicleIssuependingdisplay"><span>Vehicle Issuing</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/vehicles"><span>Vehicle Add</span></a>
                    </div>
                    </li>
                </ul>
            </div>
            <div id ="contacts">
                <ul class="navbar-nav justify-content-center w-100 px-3">
                   <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Leave
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="<?= base_url(); ?>/LeaveApply"><span>Leave</span></a>
                        <a class="dropdown-item" href="#">Manage</a>
                    </div>
                    </li>
                </ul>
            </div>
            <div id ="network">
                <ul class="navbar-nav justify-content-center w-100 px-3">
                   <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Documents
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="<?= base_url(); ?>/documents"><span>Document</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/documents/move_Pending"><span>Movements</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/Report_new/Doc_Move_find"><span>Movements Location</span></a>
                    </div>
                    </li>
                </ul>
            </div>
            <div id ="network">
                 <ul class="navbar-nav justify-content-center w-100 px-3">
                   <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Reports
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="<?= base_url(); ?>/Report_new/Doc_mineral"><span>Document Mineral Wise Reports</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/Report_new"><span>Document Type Wise Reports</span></a>
                        <a class="dropdown-item" href="<?= base_url(); ?>/Report_new/Veh_Issue_find"><span>Vehicle Issued Wise Reports</span></a>
                    </div>
                    </li>
                </ul>
            </div>
           
            <?php if(session()->has("logged_user")):?>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/dashboard/logout"><span>Logout</span></a> </li>
              </ul>
            </div>
             <?php else:?>
            <div id ="network">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/Registration"><span>Registration</span></a></li>
            </ul>
            </div>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/login"><span>Login</span></a> </li>
              </ul>
            </div>
                  
           <?php endif; ?>  
            <div id ="user">
              <ul>
                <li><?= $this->renderSection('page_loger'); ?>   </li>
              </ul>
            </div>        
           </nav>  
                
        </div>
    </div>
        
</header>
  
<?= $this-> rendersection("content") ?>  
 
   <footer class="bg-dark px-2 py-2">
    <div>
        <p class="text-center"> &copy: 2021 All copy right reserved</p>
    </div>
    
</footer> 
    
   <script>
  $("#datepicker").datepicker({dateFormat: 'yy-mm-dd',changeMonth:true,changeYear:true });
  $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd',changeMonth:true,changeYear:true });
  $("#timepicket").datepicker({date: 'h:i:sa'});
   </script> 
   <!-- JavaScript Bundle with Popper -->


  <script type='text/javascript'>
  $(document).ready(function(){
 
   $('#sel_user').change(function(){
        var data = {
            'epf_no':$('.epf_no').val();
        };
        $.ajax({
       
          method: 'POST',
          url:baseURL('/vehicleissue/FindAvailableDriver'),
          data: data,
          success: function(response
           
        
   });
  });
 });
 </script>
     <script>
            $(document).ready(function(){
 
            $(document).on('click','.save2',function(){
                
            var data = {
            'epf_no':$('.epf_no').val(),
            };
          $.ajax({
          method: 'POST',
          url:baseURL('/vehicleissue/FindAvailableDriver'),
          data: data,
          success: function(response){
              $('#').model('hide');
              alertify.set('notifyer','position','top-right');
              alertify.success(response.status);
            }
         });
       });
     });
     </script>
     
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
   google.charts.load('current', {'packages':['corechart']});
   google.charts.setOnLoadCallback(drawChart);
   function drawChart() {
   var data = new google.visualization.arrayToDataTable([
          ['Category','Number'],
          <?php
          while($row=mysqli_fetch_array($query))
          {
              echo"['".$row["catagory"]."',".$row["number"]."],";
          }
          ?>
      ]);
     var options = {'title':'Application Receiving Details',
                     'width':300,
                     'height':300};
      var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>
    
<script type="text/javascript">
   google.charts.load('current', {'packages':['corechart']});
   google.charts.setOnLoadCallback(drawChart);
   function drawChart() {
   var data = new google.visualization.arrayToDataTable([
          ['Mineral','Number'],
          <?php
          while($row=mysqli_fetch_array($query1))
          {
              echo"['".$row["mineral"]."',".$row["number"]."],";
          }
          ?>
      ]);
     var options = {'title':'Application Receiving Details Mineral Wise',
                     'width':300,
                     'height':300};
      var chart = new google.visualization.PieChart(document.getElementById('chart_div1'));
      chart.draw(data, options);
    }
    </script>
<script>
var xValues = ["New App", "Renew ", "Ext App", "Epl App", "Exp App","Reject"];
var yValues = [10, 13, 5, 3, 4,2];
var barColors = ["red", "green","blue","orange","brown","Yellow"];

new Chart("myChart2", {
  type: "pie",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: true},
    title: {
      display: true,
      text: "Today Application Received"
    }
  }
});
</script>
<script>
var xValues = ["Office Work", "Leave", "Field", "Sick", "Foriegn"];
var yValues = [785, 15, 50, 5, 2];
var barColors = [
  "#1e7145",
  "#00aba9",
  "#2b5797",
  "#b91d47",
  "#e8c3b9"
];

new Chart("pieChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Today Employees Attendent"
    }
  }
});
</script>
 <script>
var xValues = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Des"];

new Chart("mlChart", {
  type: "line",
  data: {
    labels: xValues,
    datasets: [{ 
      data: [860,1140,1060,1060,1070,1110,1330,2210,3830,2478,1850,2451],
      borderColor: "red",
      label:"New App",
      fill: false
    }, { 
      data: [1600,1700,1700,1900,2000,2700,4000,5000,6000,7000,7200,7500],
      borderColor: "green",
      label:"Renew App",
      fill: false
    }, { 
      data: [300,700,2000,5000,6000,4000,2000,1000,200,100,550,780],
      borderColor: "blue",
      label:"Ext App",
      fill: false
    }]
  },
  options: {
    legend: {display: true,
    text: "Application Receiving Details"}
  }
});
</script>   

</body>
</html>   