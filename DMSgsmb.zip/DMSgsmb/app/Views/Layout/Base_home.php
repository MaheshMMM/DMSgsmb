<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
   <meta charset="utf-8">
   <!-- CSS only -->
       <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="<?= base_url(); ?>/public/assets/CSS/styleregister.css"> 
      <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>/public/assets/js/jquery-ui.min.css">

</head>
<body>
    
    <header>
        <div class="row">
            <div class="col-md-4">
               <div id="banner">
                <ul>
                <li>  <img src="http://localhost/DMSgsmb/public/assets/images/banner.png"></li>
                </ul>
            </div> 
            </div>
            <div class="col-md4 mt-5 font-weight-bold ">
                <nav class="navbar navbar-expand-sm bg-secondry navbar-dark ">
                <div id ="home">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/home"><span>Home</span></a></li>
                </ul>
                </div>
            <div id ="home">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/dashboard"><span>Dashboard</span></a></li>
                </ul>
            </div>
           
            <?php if(session()->has("logged_user")):?>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/dashboard/logout"><span>Logout</span></a> </li>
              </ul>
            </div>
             <?php else:?>
            <div id ="network">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/Registration"><span>Registration</span></a></li>
            </ul>
            </div>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/login"><span>Login</span></a> </li>
              </ul>
            </div>
                  
           <?php endif; ?>  
            <div id ="user">
              <ul>
                <li><?= $this->renderSection('page_loger'); ?>   </li>
              </ul>
            </div>        
           </nav>  
                
        </div>
    </div>
        
</header>
  
<?= $this-> rendersection("content") ?>  
 
<footer class="bg-dark px-2 py-2 ">
 <div class="footer">
       <p class="text-center"> &copy: 2021 All copy right reserved</p>
 </div>
    
</footer> 
    
  
</body>
</html>   