<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
   <meta charset="utf-8">
   <!-- CSS only -->
       <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <link rel="stylesheet" href="<?= base_url(); ?>/public/assets/CSS/styleregister.css"> 
      <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>/public/assets/js/jquery-ui.min.css">

</head>
<body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/jquery-3.6.0.slim.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>/public/assets/js/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <header>
        <div class="row">
            <div class="col-md-4">
               <div id="banner">
                <ul>
                <li>  <img src="http://localhost/DMSgsmb/public/assets/images/banner.png"></li>
                </ul>
            </div> 
            </div>
            <div class="col-md4 mt-5 font-weight-bold ">
                <nav class="navbar navbar-expand-sm bg-secondry navbar-dark ">
                    <div id ="home">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/Home"><span>Home</span></a></li>
                </ul>
                </div>
                <div id ="home">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/Dashboard"><span>Dashboard</span></a></li>
                </ul>
                </div>
            <div id ="services">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/dashboard/vehicleReservation"><span>Vehicle</span></a> </li>
              </ul>
            </div>
            <div id ="contacts">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/LeaveApply"><span>Leave</span></a></li>
              </ul>
            </div>
            <div id ="network">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/documents"><span>Document</span></a></li>
              </ul>
            </div>
           
            <?php if(session()->has("logged_user")):?>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/dashboard/logout"><span>Logout</span></a> </li>
              </ul>
            </div>
             <?php else:?>
            <div id ="network">
                <ul>
                <li class="pad"><a href="<?= base_url(); ?>/Registration"><span>Registration</span></a></li>
            </ul>
            </div>
            <div id ="about">
              <ul>
                <li class="pad"><a href="<?= base_url(); ?>/login"><span>Login</span></a> </li>
              </ul>
            </div>
                  
           <?php endif; ?>  
            <div id ="user">
              <ul>
                <li><?= $this->renderSection('page_loger'); ?>   </li>
              </ul>
            </div>        
           </nav>  
                
        </div>
    </div>
        
</header>
  
<?= $this-> rendersection("content") ?>  
 
   <footer class="bg-dark px-2 py-2">
    <div>
        <p class="text-center"> &copy: 2021 All copy right reserved</p>
    </div>
    
</footer> 
    
   <script>
  $("#datepicker").datepicker({dateFormat: 'yy-mm-dd',changeMonth:true,changeYear:true });
  $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd',changeMonth:true,changeYear:true });
 
  $("#timepicket").datepicker({date: 'h:i:sa'});
   </script> 
   <!-- JavaScript Bundle with Popper -->


  <script type='text/javascript'>
  $(document).ready(function(){
 
   $('#sel_user').change(function(){
        var data = {
            'epf_no':$('.epf_no').val();
        };
        $.ajax({
       
          method: 'POST',
          url:baseURL('/vehicleissue/FindAvailableDriver'),
          data: data,
          success: function(response
           
        
   });
  });
 });
 </script>
     <script>
            $(document).ready(function(){
 
            $(document).on('click','.save2',function(){
                
            var data = {
            'epf_no':$('.epf_no').val(),
            };
          $.ajax({
          method: 'POST',
          url:baseURL('/vehicleissue/FindAvailableDriver'),
          data: data,
          success: function(response){
              $('#').model('hide');
              alertify.set('notifyer','position','top-right');
              alertify.success(response.status);
            }
         });
       });
     });
     </script>
</body>
</html>   