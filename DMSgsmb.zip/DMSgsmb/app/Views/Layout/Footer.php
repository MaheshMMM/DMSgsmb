<footer class="bg-primary px-2 py-2">
    <div>
        <p class="text-center"> &copy: 2021 All copy right reserved</p>
    </div>
    
</footer>

</body>
</html>