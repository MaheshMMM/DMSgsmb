<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>

<section>
    <h2 class="title">Documents Received List</h2>
    <div class="row">
            <div class="container"> 
            <?php if(!empty($cur_loc)>0): ?>
            <table class='table table-dark table-striped'>
            <tr>
                <th> Applicant Name</th>
                <th> Application No</th>
                <th> Category</th>
                <th> Mineral</th>
                <th> Regional Office</th>
                <th> Action</th>
            </tr>
            <?php foreach($cur_loc as $res): ?>
            <tr>
                <td> <?= $res->app_name; ?></td>
                <td> <?= $res->App_no; ?></td>
                <td> <?= $res->catagory; ?></td>
                <td> <?= $res->mineral; ?></td>
                <td> <?= $res->reg_office; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/Documents/Doc_Movement_save/<?= $res->id ?>">View</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
            </div>
        </div>  
      
    
</section>

<?= $this ->endsection();?>
