<?= $this ->extend("Layout/base_home"); ?> 

<?= $this ->section("content");?>

<section>
    <div >
          <div  > 
            <div id="banner">
                
                 <img class="img-fluid" alt="Responsive"  src="http://localhost/DMSgsmb/public/assets/images/Home_Banner.jpg">
                
             </div>  
          </div>     
    </div>
</section>

<?= $this ->endsection();?>

