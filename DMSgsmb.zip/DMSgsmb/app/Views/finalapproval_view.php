<?= $this ->extend("layout/Base_top_mgt"); ?>
<?php $this-> section("content"); ?>
<section>
    <div class="container">
        
    <h2 class='title'> Pending Final Approval List</h2>
        
         
    <div class="row">
        <?php if(!empty($veh_reservation)>0): ?>
        <table class='table table-dark table-striped'>
            <tr>
                
                <th> Employer Name</th>
                <th> Designation</th>
                <th> Destination</th>
                <th> Reason</th>
                <th> Reserved Date & Time</th>
                <th> Return Date & Time</th>
                <th> No of Participations</th>
                <th> Recommendation</th>
            </tr>
            <?php foreach($veh_reservation as $res): ?>
            <tr>
                
                <td> <?= $res->name; ?></td>
                <td> <?= $res->desi; ?></td>
                <td> <?= $res->distination; ?></td>
                <td> <?= $res->reason; ?></td>
                <td> <?= $res->rq_date; ?></td>
                <td> <?= $res->rt_date; ?></td>
                <td> <?= $res->part; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/VehicleIssue/finalapproved/<?= $res->id ?>">Approval</a>
                    
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
     </div>
</section>
<?= $this->endsection(); ?>