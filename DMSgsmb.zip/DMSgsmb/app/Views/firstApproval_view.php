<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>

<section>
    <h2 class="title">Pending First Approval List</h2>
    <div class="row">
            <div class="container"> 
            <?php if(!empty($veh_reservation)>0): ?>
            <table class='table table-dark table-striped'>
            <tr>
                <th> Employer Name</th>
                <th> Designation</th>
                <th> Reason</th>
                <th> Destination</th>
                <th> Departure Date/time</th>
                <th> Return Date/Time</th>
                <th> participants</th>
                <th> Action</th>
            </tr>
            <?php foreach($veh_reservation as $res): ?>
            <tr>
                <td> <?= $res->name; ?></td>
                <td> <?= $res->desi; ?></td>
                <td> <?= $res->reason; ?></td>
                <td> <?= $res->distination; ?></td>
                <td> <?= $res->rq_date; ?></td>
                <td> <?= $res->rt_date; ?></td>
                <td> <?= $res->part; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/VehicleIssue/firstapproved/<?= $res->id ?>">Approval</a>
                    
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
            </div>
        </div>  
      
    
</section>

<?= $this ->endsection();?>
