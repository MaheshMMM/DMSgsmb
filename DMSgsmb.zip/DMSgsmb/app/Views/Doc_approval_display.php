<?= $this ->extend("Layout/Base_top_mgt"); ?> 

<?= $this ->section("content");?>

<section>
    <h2 class="title">Documents Approval List</h2>
    <div class="row">
            <div class="container"> 
            <?php if(!empty($doc_appr)>0): ?>
            <table class='table table-dark table-striped'>
            <tr>
                <th> Applicant Name</th>
                <th> Application No</th>
                <th> Category</th>
                <th> Mineral</th>
                <th> Regional Office</th>
                <th> Action</th>
            </tr>
            <?php foreach($doc_appr as $res): ?>
            <tr>
                <td> <?= $res->app_name; ?></td>
                <td> <?= $res->App_no; ?></td>
                <td> <?= $res->catagory; ?></td>
                <td> <?= $res->mineral; ?></td>
                <td> <?= $res->reg_office; ?></td>
                <td>
                    <a href="<?= base_url(); ?>/Documents/Approved_Update/<?= $res->id ?>">Approved</a>
                     
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
            </div>
        </div>  
      
    
</section>

<?= $this ->endsection();?>

    