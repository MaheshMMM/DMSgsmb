<?= $this ->extend("Layout/Base_top_mgt"); ?> 
 <?php $page_session = \Config\Services::Session(); ?>
<?= $this ->section("page_loger"); ?>
     <span> Welcome <?= ucfirst($userdata['name']); ?></span>
    <?= $this ->endsection(); ?>
    <?= $this ->section("content");?>
     <div class="row justify-content-center align-items-center p-3">
        <div class="col col-sm-10 col-md-6 col-lg-4 col-xl-6">
            <div class="form-box bg-white p-3 bd-highlight rounded">
        
             <h2>Vehicle Reservation Form</h2>  
              <?php if (session()->getTempdata('success')): ?>
             <div class='alert alert-success'> <?= session()->getTempdata('success'); ?></div>
             <?php endif; ?>
        
             <?php if (session()->getTempdata('error')): ?>
             <div class='alert alert-denger'> <?= session()->getTempdata('error'); ?></div>
             <?php endif; ?> 
        <?= form_open(); ?>
             
            <div class="form-group">
                <label class="required">Employ ID(EPF No)</label>
                <input type="text" name="epf_no" class="form-control"  value='<?= $userdata['epf_no'] ?>/ <?= $userdata['name'] ?>'>
                  
            </div>
            <div class="form-group ">
                <label class="required">Request Propose </label>
                <input type="text" name="reason" class="form-control" value=''>
               <span class="text-danger"><?= display_error($validation,'reason'); ?> </span>
            </div>
            <div class="form-group">
                <label class="required">Route</label>
               <input type="text" name="route" class="form-control" value=''>
               <span class="text-danger"><?= display_error($validation,'route'); ?> </span> 
               <!-- see home view drop down -->
                
            </div>
            <div class="form-group ">
                <label class="required">Destination</label>
                <input type="text" name="distination" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'distination'); ?> </span> 
            </div>
            <div class="form-group ">
                <label class="required">Request Date & Time</label>
                <input type="datetime-local" name="rq_date" class="form-control" value=''>
              <span class="text-danger"><?= display_error($validation,'rq_date'); ?> </span>  
            </div>
            
            <div class="form-group ">
                <label class="required">Return Date & Time</label>
                <input type="datetime-local" name="rt_date"  class="form-control" value=''>
              <span class="text-danger"><?= display_error($validation,'rt_date'); ?> </span>  
            </div>
            
            <div class="form-group ">
                <label class="required">No of Passangers</label>
               <input type="text" name="part" class="form-control" value=''>
                <span class="text-danger"><?= display_error($validation,'part'); ?> </span> 
            </div>
            <div class="form-group ">
                <label>Remark</label>
                <input type="text" name="remark" class="form-control" value=''>
                 
            </div>
           
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
               
            </div>
                
        </div>
    </div>
                
  </div>
<?= $this->endsection(); ?>


