<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Codeigniter 4 PDF Generate Example - Tutsmake.com</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<h2 class="text-center">Geological Survey and Mines Bureau</h2>
<h4 class="text-center">Annually Travel Details(Vehicle wise)</h4>
<div class="d-flex flex-row-reverse bd-highlight">
<a href="<?php echo base_url('Report_new/htmlToPDF') ?>" class="btn btn-primary">
Download PDF
</a>
</div>
<table class="table table-striped table-hover mt-4">
<thead>
<tr>
<th>Vehicle No</th>
<th>Vehicle Type</th>
<th>Product Year</th>
<th>Travel Days</th>
<th>Traveling Km</th>
<th>Ideal Days</th>
<th>DreakDown Days</th>
<th>Fuel Coast</th>
</tr>
</thead>
<tbody>
<tr>
<td>WPLA-1578</td>
<td>Cab</td>
<td>2018</td>
<td>260</td>
<td>13000</td>
<td>103</td>
<td>2</td>
<td>219,000.00</td>
</tr>
<tr>
<td>WPLA-1551</td>
<td>Cab</td>
<td>2018</td>
<td>289</td>
<td>13480</td>
<td>71</td>
<td>5</td>
<td>235,060.00</td>
</tr>
<tr>
<td>WPLA-1470</td>
<td>Cab</td>
<td>2018</td>
<td>266</td>
<td>12469</td>
<td>96</td>
<td>3</td>
<td>248,500.00</td>
</tr>
<tr>
<td>WPLA-1650</td>
<td>Cab</td>
<td>2018</td>
<td>232</td>
<td>12739</td>
<td>123</td>
<td>10</td>
<td>214,970.00</td>
</tr>
<tr>
<td>WPGN-5790</td>
<td>Cab</td>
<td>2015</td>
<td>272</td>
<td>10247</td>
<td>87</td>
<td>6</td>
<td>138,245.00</td>
</tr>
<tr>
<td>WPGN-6845</td>
<td>Cab</td>
<td>2015</td>
<td>235</td>
<td>8452</td>
<td>112</td>
<td>18</td>
<td>168,300.00</td>
</tr>
<tr>
<td>WPKD-4589</td>
<td>Lorry</td>
<td>2017</td>
<td>164</td>
<td>5752</td>
<td>198</td>
<td>3</td>
<td>129,420.00</td>
</tr>
<tr>
<td>WPKA-4698</td>
<td>Car</td>
<td>2015</td>
<td>310</td>
<td>14578</td>
<td>48</td>
<td>7</td>
<td>165,480.00</td>
</tr>
<tr>
<td>WPKA-4600</td>
<td>Car</td>
<td>2015</td>
<td>268</td>
<td>3850</td>
<td>48</td>
<td>49</td>
<td>52,735.00</td>
</tr>
<tr>
<td>250-1008</td>
<td>Lorry</td>
<td>2005</td>
<td>108</td>
<td>5705</td>
<td>242</td>
<td>15</td>
<td>96,450.00</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>