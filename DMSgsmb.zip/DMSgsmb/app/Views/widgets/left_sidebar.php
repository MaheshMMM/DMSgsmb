<div class="container bg-dark higth-auto d-inline-block">
    <div  >
        <h5 class="card-header text-danger align-center"> Pending Approvals</h5>
            <div class="card-body">
                
                    <ul>
                    <li><h5 class="text-info">  Vehicle Reservations</h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">First Approval</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">Final Approval</a><li>
                    
                    </ul> 
            
                      
                    <ul>
                    <li> <h5 class="text-info"> Leave Apply</h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">First Approval</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">Final Approval</a><li>
                    
                    </ul> 
            
                      
                    <ul>
                    <li> <h5 class="text-info"> File Movements</h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/Documents/pendingApprovaldisplay">Doc Approval</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/Documents/move_Pending">Doc Movements</a><li>
                    </ul> 
                    <ul>
                    <li> <h5 class="text-info"> Meeting Room </h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">First Approval</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">Final Approval</a><li>
                    </ul> 
                <ul>
                    <li> <h1 class="text-info">  </h1></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay"></a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay"></a><li>
                        <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay"></a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay"></a><li>
                        <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay"></a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay"></a><li>
                    </ul> 
        </div>
    </div>
</div>