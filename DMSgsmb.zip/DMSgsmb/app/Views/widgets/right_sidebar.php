<div>
    <div class="container ">
        <h5 class="card-header text-danger align-center"> Manage Request </h5>
            <div class="card-body">
               
                    <ul>
                        <li><h5 class="text-info">  Approved</h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">Vehicles</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">File Reserved</a><li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/vehicleissue/vehicleIssuependingdisplay">Leave chits</a><li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/vehicleissue/vehicleIssuependingdisplay">meeting room</a><li>
                    </ul> 
            </div>  
                <div class="card-body">           
                    <ul>
                    <li><h5 class="text-info">Reject Request</h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">Vehicles</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">Leave chits</a><li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/vehicleissue/vehicleIssuependingdisplay">meeting room</a><li>
                    </ul>
               </div>  
                <div class="card-body">       
                     <ul>
                    <li> <h5> <a class="nav-link" href="<?= base_url(); ?>/VehicleReservation">Completed</a></h5></li>
                    <li><a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/pendingdisplay">File Movement</a></li>
                    <li> <a class="nav-link" href="<?= base_url(); ?>/VehicleIssue/finalpendingdisplay">Leave chits</a><li>
                    </ul> 
           
        </div> 
    </div>
</div>