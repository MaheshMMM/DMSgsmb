<?= $this ->extend("Layout/Base_top_mgt"); ?> 
   <?php $page_session = \Config\Services::Session(); ?>
<?= $this ->section("content");?>
<h2 class="title">Documents Received List</h2>
    <div class="row">
            <div class="container"> 
            <?php if(!empty($docs)>0): ?>
            <table class='table table-dark table-striped'>
            <tr>
                <th> Mineral</th>
                <th> No of App</th>
                
            </tr>
            <?php foreach($docs as $res): ?>
            <tr>
                <td> <?= $res->mineral; ?></td>
                <td> <?= $res->count; ?></td>
                
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
            </div>
        </div>  


<?= $this ->endsection();?>