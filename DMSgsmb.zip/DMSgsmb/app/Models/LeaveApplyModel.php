<?php
namespace App\Models;
use CodeIgniter\Model;

class LeaveApplyModel extends Model {
    
    public function ApplyLeave($data){
        $builder = $this -> db -> table('emp_leave');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
    
}

}