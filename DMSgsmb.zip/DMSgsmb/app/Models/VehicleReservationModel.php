<?php

namespace App\Models;
use CodeIgniter\Model;

class VehicleReservationModel extends Model{
    public function vehreseradd($data){
    $builder = $this -> db -> table('veh_reservation');
        $res = $builder-> insert($data);
        
       
}

}