<?php
namespace App\Models;
use \CodeIgniter\Model;

class DocumentsModel extends Model{
     protected $table = 'documents'; 
     protected $primaryKey = 'id';
     protected $returnType = 'array';
    
     public function doc_cat_dash(){
         $db = \Config\Database::connect();
         $sql = "select catagory, Count(*)as number from Documents group by catagory ";
         $query = $db->query($sql);
         $result = $query->getResult();
         if(count($result)>0){
            return $result;
        }
        else{
            return false;
        }
     }
     public function doc_cat_dash2(){
         $db = \Config\Database::connect();
         $sql = "select mineral, Count(*)as number from Documents group by mineral ";
         $query = $db->query($sql);
         $result = $query->getResult();
         if(count($result)>0){
            return $result;
        }
        else{
            return false;
        }
     }
   
    public function userlist(){
        $db = \Config\Database::connect();
        $sql = "select * from users ";
        $query = $db->query($sql);
        $result = $query->getResult();
        if(count($result)>0){
            return $result;
        }
        else{
            return false;
        }
    }
    public function docsave($data){
        $builder = $this -> db -> table('documents');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
       
    }
     public function docupdate($data){
        $builder = $this -> db -> table('documents');
        $builder->where('id',6);
        $builder-> update($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
       
    }
    public function doc_for_approval(){
    $db = \Config\Database::connect();
    $sql = "select * from documents where status= ? ";
    $query = $db->query($sql, 'pending');
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    public function ApplicationAllData($id){
    $db = \Config\Database::connect();
    $sql = "select * from documents where id=?  ";
    $query = $db->query($sql,$id);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    public function ApplicationDetailLoad($id){
    $db = \Config\Database::connect();
    $sql = "select * from doc_move_view where id=?  ";
    $query = $db->query($sql,$id);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }

     
    public function update_doc_approval($id,$data){
    $builder=$this->db->table('documents');
    $builder->where('id',$id);
    $builder->update($data);
    }
    public function Doc_Mov_Pen_Display($id){
    $db = \Config\Database::connect();
    $sql = "select * from documents where status='approved' and current_location= ? ";
    $query = $db->query($sql, $id);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
   
     public function doc_MoveOne_save($data){
        $builder = $this -> db -> table('doc_movements');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
    }
  
    public function doc_Move_save($data){
        $builder = $this -> db -> table('doc_movements');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
       
    }
    public function document_movement_change($id,$data){
    $builder=$this->db->table('documents');
    $builder->where('id',$id);
    $builder->update($data);
    }
    public function Doc_Report_PW($data){
        $builder= $this->db->table('Documents');
        $builder->where('received_date >=',$data['st_date']);
        $builder->where('received_date <=',$data['en_date']);
        $builder->where('doc_type =',$data['doc_type']);
        $query= $builder->get()->getresult();
        return $query;
    }
    public function Doc_Report_Min(){
        $db = \Config\Database::connect();
    $sql = "select mineral, count(mineral)as count from documents group by mineral  ";
    $query = $db->query($sql);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    
    
    
    
    
    
    public function Doc_Mov_RelatedAll_Display($id){
    $db = \Config\Database::connect();
    $sql = "select * from movementall Where App_no=? ";
    $query = $db->query($sql, $id['App_no']);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    public function Summery_Report_Min(){
        $db = \Config\Database::connect();
    $sql = "select * from documents where status='approved' and current_location= ? ";
    $query = $db->query($sql, $id);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    
    
}
