<?php

namespace App\Models;
use CodeIgniter\Model;


class VehicleIssueModel extends Model {
   protected $table = 'veh_receive_issued_emp'; 
   protected $primaryKey = 'id';
   protected $returnType = 'array';

 public function list_of_drivers(){
    $db = \Config\Database::connect();
    $sql='select * from non_reg_drivers where desi =? ';
    $query = $db->query($sql,['Driver']);
    $result = $query->getResult();
    if(count($result)>0){
    return $result;
    }
    else{

    return false;
    }
    }
    public function adddriver($data){
        $builder = $this -> db -> table('drivers');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
    }
    public function vehicleissuesave($data){
        $builder = $this -> db -> table('vehicle_issue');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
    }
    public function veh_issue_pending(){
    $db = \Config\Database::connect();
    $builder = $this->db->table('users');
    $builder->join('veh_receive_issued','users.epf_no = veh_receive_issued.epf_no');
    $builder->where(['veh_receive_issued.status2'=>'Approved']);
    $builder->where(['veh_receive_issued.driver_id'=> NULL]);
    $result = $builder->get()->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
         public function pending_relavant($id){
        $db = \Config\Database::connect();
        $sql='select * from veh_reser_user_issue where id =?';
        $query = $db->query($sql,'$id');
        $result = $query->getResult();
        if(count($result)>0){
        return $result;
        }
        else{
            
        return false;
        }
    }
    public function verify_no_approval(){
    $db = \Config\Database::connect();
    $builder = $this->db->table('users');
    $builder->join('veh_reservation','users.epf_no = veh_reservation.epf_no');
    $builder->where(['veh_reservation.status1'=>'pending']);
    $builder->where(['veh_reservation.status2'=>'pending']);
    $result = $builder->get()->getResult();
    //$sql = "select id,epf_no,distination,route,rq_date,rt_date,part,remark,reason from veh_reservation where status1= ? and status2=?";
    //$query = $db->query($sql, ['pending','pending']);
    //$result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
    }
    public function verify_hod_approval(){
    $db = \Config\Database::connect();
    $builder = $this->db->table('users');
    $builder->join('veh_reservation','users.epf_no = veh_reservation.epf_no');
    $builder->where(['veh_reservation.status2'=>'pending']);
    $result = $builder->get()->getResult();
    return $result;
// $sql = "select id,epf_no,distination,route,rq_date,rt_date,part,remark from veh_reservation where status2= ? ";
    //$query = $db->query($sql, ['pending']);
    //$result = $query->getResult();
    //if(count($result)>0){
     //   return $result;
    //}
   // else{
    //    return false;
   // }
    }
public function update_vr_approval($id){
    $builder=$this->db->table('veh_reservation');
    $builder->where('id',$id);
    $builder->update(['status1'=>'approved']);
    if($this->db->affectedRows()==1){ 
    return true;
    }else{
    return false;
    }
           
}
 public function update_hod_approval($id){
    $builder=$this->db->table('veh_reservation');
    $builder->where('id',$id);
    $builder->update(['status2'=>'approved']);
    if($this->db->affectedRows()==1){ 
    return true;
    }else{
    return false;
    }      
}
public function availableDriverList(){
    
   $builder = $this->db->table('users');
    $builder->join('driver_receive_issued','users.epf_no = driver_receive_issued.epf_no');
    $builder->where(['driver_receive_issued.attach_unit'=>'pool']);
    $result = $builder->get()->getResult();
     if(count($result)>0){
    return $result;
    }
    else{
        return false;
    }
    }
     //[start_date] => 2021-08-28
                    //[end_date] => 2021-08-29
function join(){
    return $this->db->table('users')
            ->where('start_date !=','2021-08-20')
            ->where('end_date !=','2021-09-03')
            ->orWhere('end_date',Null)
            ->orWhere('end_date',Null)
            ->join('driver_receive_issued','users.epf_no = driver_receive_issued.epf_no')
            ->get()
            ->getResult();
}
public function availableVehicleList(){
   return $this->db->table('vehicle')
            ->where('v_own =','GSMB')
            ->get()
            ->getResult();
}   

function vehicleIssueTo(){
    return $this->db->table('users')
            ->join('driver_receive_issued','users.epf_no = driver_receive_issued.epf_no')
            ->get()
            ->getResult();
}
}
