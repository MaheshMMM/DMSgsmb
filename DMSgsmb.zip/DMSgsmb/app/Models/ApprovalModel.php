<?php

namespace app\Models; 
use CodeIgniter\Model;


class ApprovalModel extends Model{
    protected $table = 'approval_view';
    protected $primaryKey = 'id';
    protected $allowedFields =['epf_no','reason','rq_date','part','distination'];
    protected $useTimestamps = true;
    protected $retunType = 'array';
}
