<?php

namespace App\Models;
use CodeIgniter\Model;

class RegistrationModel extends Model {
        protected $table = 'Designation';
        protected $primeryKey = 'id';
    public function createemploy($data){
        $builder = $this -> db -> table('users');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
       
    }
    public function verifyUniid($id){
        $builder = $this->db->table('users');
        $builder->select('appro_date,uniid,status');
        $builder->where('uniid,$id)');
        $result = $builder->get();
        if($builder->countAll()==1){
            return $result->getRow();
        }
        else{
            return false;
        }
     }
     public function designation(){
       
    $sql = "select id,desi,p_level from designation ";
    $query = $this->db->query($sql);
    $result = $query->getResult();
    if(count($result)>0){
        return $result;
    }
    else{
        return false;
    }
      
    }
    
    
     }

