<?php
namespace App\Models;
use \CodeIgniter\Model;

class DashboardModel extends Model {
    protected $table = 'veh_reservation';
    protected $primeryKey = 'id';
    
public function getLoggedInUserData($id){
    $builder = $this->db->table('users');
    $builder->where('epf_no',$id);
    $result = $builder->get();
    if(count($result->getResultArray())==1){
        return $result->getRow();  
    }
    else{
        return false;
    }
}     
  public function updateLogoutTime($id){
    $builder=$this->db->table('login_activity');
    $builder->where('id',$id);
    $builder->update(['log_out'=>date('Y-m-d h:i:s')]);
    if($this->db->affectedRows()>0){
        return true;
    }
}  
public function findLogindata($id){
    $builder=$this->db->table('login_user_view');
    $builder->where('id',$id);
    $result = $builder->get();
    if(count($result->getResultArray())==1){
        return $result->getRowArray();  
    }
    else{
        return false;
    }
    } 
public function VehResupdate($id,$data){
    $builder=$this->db->table('veh_reservation');
    $builder->where('id',$id);
    $builder->update($data);
    if($this->db->affectedRows()>0){
        return true;
    }
}      
           
}

