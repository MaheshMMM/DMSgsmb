<?php

namespace App\Models;
use CodeIgniter\Model;


class VehicleRegistrationModel extends Model {
    public function addvehicle($data){
        $builder = $this -> db -> table('vehicle');
        $res = $builder-> insert($data);
        if($this->db->affectedRows()==1){
            return true;
            }else{
            return false;  
            }
}
}