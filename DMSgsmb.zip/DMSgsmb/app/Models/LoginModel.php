<?php

namespace App\Models;
use CodeIgniter\Model;

class LoginModel extends Model{
    public function verifyEPF($epf_no){
      $builder = $this->db->table('designation'); 
      $builder->join("users","users.desi=designation.desi");
      $builder->select("status,pw,name,uniid,epf_no,p_level");
      $builder->where("epf_no",$epf_no);
      $result = $builder->get();
      if(count($result->getResultArray())==1){
          return $result->getRowArray();
      }
      else{
          return false;
      }
    }
    public function find_uselevel($epf_no){
      $builder = $this->db->table('designation');
      $builder->join("users,users.desi=designation.desi");
      $builder->select("epf_no,p_level");
      $builder->where("epf_no",$epf_no);
      $result = $builder->get();
      if(count($result->getResultArray())==1){
          return $result->getRowArray();
      }
      else{
          return false;
      }
    }
    public function saveLoginInfo($data){
        $builder = $this->db->table('login_activity');
        $builder->insert($data);
        if($this->db->affectedRows()==1){
            return $this->db->insertID();
        }
        else{
            return false;
        }
            
    }
}
